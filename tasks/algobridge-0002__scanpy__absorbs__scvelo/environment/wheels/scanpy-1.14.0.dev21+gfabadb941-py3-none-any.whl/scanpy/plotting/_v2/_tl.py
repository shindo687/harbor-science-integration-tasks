from __future__ import annotations

from typing import TYPE_CHECKING, cast

import holoviews as hv
import numpy as np
import pandas as pd
from anndata.acc import GraphAcc, MultiAcc
from hv_anndata import A

if TYPE_CHECKING:
    from typing import Literal

    from anndata import AnnData
    from hv_anndata import AdDim
    from scipy.sparse import csr_matrix  # noqa: TID251


def draw_graph(
    adata: AnnData,
    kdims: list[AdDim] | MultiAcc,
    edge_vdim: Literal["distances", "connectivities"] | GraphAcc = "connectivities",
    node_vdims: AdDim | list[AdDim] | None = None,
    *,
    neighbors_key: str = "neighbors",
) -> hv.Graph:
    """Draw a graph.

    Parameters
    ----------
    adata
        Annotated data matrix.
    kdims
        Key dimensions of the graph.
        Can just be ``A.obsm[<k>]`` or ``A.varm[<k>]`` to auto-select components.
    edge_vdim
        Edge value dimension.
        If ``"distances"``/``"connectivities"``,
        the graph data is retrieved like :func:`scanpy.pp.neighbors` stores it:
        ``A.uns[neighbors_key][f"{edge_vdim}_key"]``.
        Therefore ``.opts(edge_color=calculated_edge_vdim)`` is set by default.
    node_vdims
        Node value dimensions.
    neighbors_key
        Key in ``adata.uns`` where neighbors are stored.
        Used only if ``edge_vdim`` is ``"distances"``/``"connectivities"``.

    Returns
    -------
    Graph with colored edges.

    Examples
    --------

    ..  holoviews::
        :backends: bokeh,matplotlib

        import scanpy as sc

        sc.settings.preset = sc.Preset.ScanpyV2Preview
        A = sc.pl.hv_init(FAKE_BACKEND)

        adata = sc.datasets.pbmc68k_reduced()
        sc.pp.neighbors(adata)
        sc.pl.draw_graph(
            adata, A.obsm["umap"], "distances", [A.obs["bulk_labels"]]
        ).opts(
            node_color=A.obs["bulk_labels"],
            node_cmap="tab10",
            aspect="square",
            show_legend=True,
            legend_position="right",
        )

    .. note:: The `"plotly"` backend does not support graphs: :issue:`holoviz/holoviews#6949`.

    """
    adata = adata.copy()
    adata.obs["cell index"] = range(adata.n_obs)
    if isinstance(kdims, MultiAcc):
        kdims = [kdims[0], kdims[1]]
    if isinstance(edge_vdim, str):
        edge_vdim = A.obsp[adata.uns[neighbors_key][f"{edge_vdim}_key"]]
    elif not isinstance(edge_vdim, GraphAcc):
        msg = f"edge_vdim must be a string or `A.obsp[key]`, got {edge_vdim!r}."
        raise TypeError(msg)

    edges = cast("csr_matrix", getattr(adata, f"{edge_vdim.dim}p")[edge_vdim.k]).tocoo()
    nodes = hv.Nodes(adata, [*kdims, A.obs["cell index"]], node_vdims)
    return hv.Graph(((*edges.coords, edges.data), nodes), vdims=edge_vdim[:, :]).opts(
        edge_color=edge_vdim[:, :]
    )


def ranking(
    adata: AnnData,
    ref: AdDim,
    /,
    n_points: int = 10,
    *,
    include_lowest: bool = True,
    label_dim: AdDim | None = None,
) -> hv.Labels:
    """Plot (e.g. PCA) score ranking.

    Parameters
    ----------
    adata
        Annotated data matrix.
    ref
        Dimension containing scores to rank.
    n_points
        Number of points to plot.
    include_lowest
        Whether to include the lowest-scored names in addition to the highest-scored ones.
    label_dim
        Dimension to use for labels.
        The default is ``dim``’s axis index (e.g. ``A.obs.index`` for ``A.obs["scores"]``).

    Returns
    -------
    Holoviews plot with labels and points.

    Examples
    --------
    Rank genes by their loading on a principal component
    (replaces the legacy :func:`~scanpy.pl.pca_loadings`):

    ..  holoviews::

        import scanpy as sc
        import holoviews as hv

        sc.settings.preset = sc.Preset.ScanpyV2Preview
        A = sc.pl.hv_init(FAKE_BACKEND)

        adata = sc.datasets.pbmc68k_reduced()
        hv.Layout([
            sc.pl.ranking(adata, A.varm["PCs"][0]).opts(aspect=1.2),
            sc.pl.ranking(adata, A.varm["PCs"][0], include_lowest=False).opts(aspect=0.6),
        ]).opts(shared_axes=False)

    Rank principal components by their explained variance ratio
    (replaces the legacy :func:`~scanpy.pl.pca_variance_ratio`),
    using :func:`~scanpy.get.pca` to expose it as a `.var` column:

    ..  holoviews::

        pca_adata = sc.get.pca(adata)
        sc.pl.ranking(pca_adata, A.var["variance_ratio"], include_lowest=False)

    """
    [dim] = ref.dims
    if label_dim is None:
        label_dim = getattr(A, dim).index
    # full arrays
    scores = adata[ref]
    labels = adata[label_dim]

    # subset, ignoring entries without a score (`np.argsort` would otherwise
    # sort `NaN`s to the top, e.g. genes masked out of a restricted PCA)
    valid = np.flatnonzero(~np.isnan(scores))
    order = valid[np.argsort(scores[valid])]
    idx_top, idx_bot = order[-n_points:][::-1], order[:n_points][::-1]
    scores = np.r_[scores[idx_top], np.nan, scores[idx_bot]]
    labels = np.r_[labels[idx_top], ["⋯"], labels[idx_bot]]

    # prepare
    data = pd.DataFrame(
        dict(
            rank=np.arange(n_points * 2 + 1),
            score=np.where(np.isnan(scores), np.nanmean(scores), scores),
            dot=np.r_[[True] * n_points, False, [True] * n_points].astype(float),
            text=labels,
            align=np.r_[["right"] * n_points, ["center"], ["left"] * n_points],
        )
    )
    if not include_lowest:
        i = data[:n_points]["score"].diff().abs().argmax()
        data = data[:n_points].assign(
            align=np.r_[["right"] * i, ["left"] * (n_points - i)]
        )

    return hv.Labels(data, ["rank", "score"], ["text", "align"]).opts(
        angle=90, text_align="align", xticks=0
    ) * hv.Points(data[data["dot"] > 0], ["rank", "score"], ["text"])


def embedding_density(
    adata: AnnData,
    basis: MultiAcc,
    *,
    groupby: str | None = None,
    key: str | None = None,
) -> hv.Scatter | hv.NdLayout:
    """Plot embedding density.

    Parameters
    ----------
    adata
        Annotated data matrix.
    basis
        Embedding to plot (e.g. ``A.obsm["umap"]``).
    groupby
        ``groupby`` as specified in :func:`scanpy.tl.embedding_density`.
    key
        ``key_added`` as specified in :func:`scanpy.tl.embedding_density`.

    Returns
    -------
    Scatter plot if ``groupby is None``, else a layout of scatter plots.

    Examples
    --------

    ..  holoviews::

        import scanpy as sc

        sc.settings.preset = sc.Preset.ScanpyV2Preview
        A = sc.pl.hv_init(FAKE_BACKEND)

        adata = sc.datasets.pbmc68k_reduced()
        sc.tl.embedding_density(adata, basis="umap", groupby="phase")
        sc.pl.embedding_density(adata, A.obsm["umap"], groupby="phase")

    """
    basis_name = basis.k.removeprefix("X_")
    if key is None:
        key = f"{basis_name}_density{'' if groupby is None else f'_{groupby}'}"

    groupby_vdims = [] if groupby is None else [A.obs[groupby]]
    scatter = hv.Scatter(adata, basis[0], [basis[1], *groupby_vdims, A.obs[key]]).opts(
        color=A.obs[key],
        aspect="square",
        xlabel=f"{basis_name} 1",
        ylabel=f"{basis_name} 2",
        legend_position="right",
    )
    if groupby is None:
        return scatter
    return scatter.groupby(A.obs[groupby], hv.NdLayout)
