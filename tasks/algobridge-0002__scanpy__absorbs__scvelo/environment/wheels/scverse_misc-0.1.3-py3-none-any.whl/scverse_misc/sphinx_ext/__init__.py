from __future__ import annotations

import re
import sys
import textwrap
import traceback
import warnings
from importlib.metadata import version
from pathlib import Path
from types import MethodType
from typing import TYPE_CHECKING, Any, Generic, Literal, cast, get_origin

if sys.version_info >= (3, 13):
    from warnings import deprecated as deprecated
else:
    from typing_extensions import deprecated as deprecated

from jinja2.defaults import DEFAULT_FILTERS  # type: ignore[attr-defined]
from pydocstring import Document, Parsed, Style, TextBlock, emit_google, emit_numpy, parse
from pydocstring.model import Block, Docstring, Parameter, Return, Section, SectionKind
from sphinx.ext.autodoc import Options as AutodocOptions
from sphinx.ext.autodoc import import_object
from sphinx.ext.napoleon import NumpyDocstring  # type: ignore[attr-defined]
from sphinx.util import logging

from .._deprecated import Deprecation, deprecated_arg
from .._extensions import _NSInfo
from .._utils import get_packagename, type_str
from ..constants import ATTR_DEPRECATED, ATTR_DEPRECATED_ARG, ATTR_NAMESPACE

try:
    from pydantic_core import PydanticUndefined

    from .._settings import Settings
except ImportError:
    if not TYPE_CHECKING:
        Settings = type("Settings", (), {})


if TYPE_CHECKING:
    from collections.abc import Generator, Iterable

    from sphinx.application import Sphinx
    from sphinx.ext.autodoc import _AutodocObjType  # type: ignore[attr-defined]
    from sphinx.util.typing import ExtensionMetadata


__all__ = ["setup"]

_logger = logging.getLogger(__package__)


def setup(app: Sphinx) -> ExtensionMetadata:  # noqa: D103
    app.setup_extension("sphinx.ext.autodoc")
    # To go first, we use a lower number than napoleon (which uses the default, 500)
    app.connect("autodoc-process-docstring", _process_docstring, priority=100)
    app.connect("autodoc-process-bases", _skip_private_bases)

    DEFAULT_FILTERS["member_type"] = _member_type

    app.config.templates_path = list(app.config.templates_path) + [str(Path(__file__).parent / "templates")]

    NumpyDocstring._parse_returns_section = _parse_returns_section  # type: ignore[assignment]

    return {"version": version("scverse-misc"), "parallel_read_safe": True}


def _process_return(lines: Iterable[str]) -> Generator[str, None, None]:
    for line in lines:
        if m := re.fullmatch(r"(?P<param>\w+)\s+:\s+(?P<type>[\w.]+)", line):
            yield f"-{m['param']} (:class:`~{m['type']}`)"
        else:
            yield line


def _parse_returns_section(self: NumpyDocstring, section: str) -> list[str]:
    """Add support for prose return sections in Numpy-style docstrings."""
    lines_raw = self._dedent(self._consume_to_next_section())
    if lines_raw[0] == ":":
        del lines_raw[0]
    lines = self._format_block(":returns: ", list(_process_return(lines_raw)))
    if lines and lines[-1]:
        lines.append("")
    return lines


def _skip_private_bases(app: Sphinx, name: str, obj: type, _unused: Any, bases: list[type]) -> None:  # noqa: ANN401
    bases[:] = [b for b in bases if b is not object and get_origin(b) is not Generic and not b.__name__.startswith("_")]


def _member_type(obj_path: str) -> Literal["method", "property", "attribute"]:
    """Determine object member type.

    E.g.: `.. auto{{ fullname | member_type }}::`
    """
    # https://jinja.palletsprojects.com/en/stable/api/#custom-filters
    cls_path, cls_name, member_name = obj_path.rsplit(".", 2)
    try:
        cls = import_object(cls_path, [cls_name], "class")[-1]
    except ImportError:
        _logger.error(
            f"Failed to import {cls_name} from {cls_path}; the following exception was rased: {traceback.format_exc()}"
        )
        return "attribute"
    member = getattr(cls, member_name, None)
    match member:
        case property():
            return "property"
        case _ if callable(member):
            return "method"
        case _:
            return "attribute"


def _process_docstring(
    app: Sphinx, objtype: _AutodocObjType, name: str, obj: object, options: AutodocOptions, lines: list[str]
) -> None:
    match objtype:
        case "function" | "decorator" if hasattr(obj, ATTR_NAMESPACE):
            assert isinstance(getattr(obj, ATTR_NAMESPACE), _NSInfo)
            _process_namespace_decorator(app, name, getattr(obj, ATTR_NAMESPACE), lines)
        case "method" | "function" if isinstance(obj, MethodType) and isinstance(obj.__self__, Settings):
            _process_settings_method(app, obj, lines)
        case "method" | "function" | "property" | "class" | "exception":
            if isinstance(obj, property):
                obj = obj.fget
            if hasattr(obj, ATTR_DEPRECATED) and isinstance(msg := getattr(obj, ATTR_DEPRECATED, None), Deprecation):
                _process_deprecated_function(app, msg, lines)
            if (args := getattr(obj, ATTR_DEPRECATED_ARG, None)) is not None:
                _process_deprecated_args(app, args, lines)
        case "data" if isinstance(obj, Settings):
            _process_settings_object(obj, name, lines)


def _emit_docstring(
    app: Sphinx,
    model: Docstring,
    lines: list[str],
) -> None:
    """Emit a docstring compatible with the user settings (i.e. renderable with the chosen napoleon settings)."""
    if getattr(app.config, "napoleon_google_docstring", True):
        doc = emit_google(model)
    elif getattr(app.config, "napoleon_numpy_docstring", True):
        doc = emit_numpy(model)
    else:
        warnings.warn(
            "Neither Google-style nor Numpy-style docstrings are enabled. Skipping docstring generation.", stacklevel=2
        )
        return
    lines[:] = doc.strip("\n").splitlines()


def _process_deprecated_function(app: Sphinx, msg: Deprecation, lines: list[str]) -> None:
    parsed = parse("\n".join(lines))
    doc = Document(parsed)
    edits = parsed.edit()

    notice = f".. version-deprecated:: {msg.version_deprecated}"
    if len(msg):
        notice += f"\n{textwrap.indent(msg._docmsg or '', 3 * ' ')}"
    if doc.extended_summary is not None and not doc.extended_summary.is_missing():
        notice += f"\n\n{doc.extended_summary.text}"
        edits.replace(doc.extended_summary.range, notice)
    elif doc.summary is not None:
        edits.insert(doc.summary.range.end, f"\n\n{notice}")
    else:
        edits.insert(doc.range.start, notice)
    lines[:] = edits.apply().splitlines()


def _starts_own_line(parsed: Parsed, elem: TextBlock) -> bool:
    return parsed.line_col(elem.range.start).col == len(parsed.line_indent(elem.range.start))


def _process_deprecated_args(app: Sphinx, deprecations: list[deprecated_arg], lines: list[str]) -> None:
    parsed = parse("\n".join(lines))
    if parsed.style is Style.PLAIN:
        return

    doc = Document(parsed)
    edits = parsed.edit()
    for par, deprecation in (
        (par, deprecation)
        for section in doc.sections
        if section.kind in {SectionKind.PARAMETERS, SectionKind.KEYWORD_PARAMETERS, SectionKind.OTHER_PARAMETERS}
        for par in section.entries
        for deprecation in deprecations
        if deprecation.arg in (name.text for name in par.names)
    ):
        desc = par.description

        # https://github.com/ryumasai/pydocstring/pull/140#issuecomment-4966943642
        if desc is not None and _starts_own_line(parsed, desc):
            indentation = parsed.line_indent(desc.range.start)
        elif desc is not None and len(desc.lines) > 1:
            indentation = parsed.line_indent(desc.lines[1].range.start)
        else:
            indentation = parsed.line_indent(par.range.start) + "    "
        docmsg = f".. version-deprecated:: {deprecation.msg.version_deprecated}"
        if len(deprecation.msg):
            docmsg += f"\n{textwrap.indent(deprecation.msg, '   ')}"

        docmsg_lines = docmsg.splitlines()
        if len(docmsg_lines) > 1:
            docmsg = f"\n{indentation}".join(docmsg_lines)

        if desc is None:
            edits.insert(par.range.end, f"\n{docmsg}")
        else:
            edits.replace(desc.range, f"{docmsg}\n\n{indentation}{desc.text}")

    lines[:] = edits.apply().splitlines()


_settings_docstring_template = """Allows users to customize settings for the `{package}` package.

Settings here will generally be for advanced use-cases and should be used with caution.

For setting an option use :func:`~{name}.override` (local) or set the attributes directly (global)
e.g., `{name}.my_setting = foo`. For assignment by environment variable, use the variable name in
all caps with `{env_prefix}` as the prefix before import of `{package}`.

The following options are available:

"""


def _get_objname(name: str) -> str:
    dotidx = name.rfind(".")
    if dotidx > -1:
        name = name[dotidx + 1 :]
    return name


def _process_settings_object(settings: Settings, name: str, lines: list[str]) -> None:
    package = get_packagename(name)

    doc = _settings_docstring_template.format(
        package=package,
        name=name,
        env_prefix=settings.model_config["env_prefix"].upper(),
    ).splitlines()

    objname = _get_objname(name)
    for fname, field in settings.__class__.model_fields.items():
        doc.append(f".. attribute:: {objname}.{fname}")
        doc.append(f"   :type: {type_str(type(settings), field)}")

        if field.default is not PydanticUndefined:
            doc.append(f"   :value: {field.default!r}")

        deprecation_version = "???"
        deprecation_msg = None
        match field.deprecated:
            case deprecated():
                deprecation_msg = field.deprecated.message
                if isinstance(field.deprecated.message, Deprecation):
                    deprecation_version = field.deprecated.message.version_deprecated
            case str():
                deprecation_msg = field.deprecated
            case True:
                deprecation_msg = ""
        if deprecation_msg is not None:
            doc.append("")
            doc.append(f"   .. version-deprecated:: {deprecation_version}")
            doc.append(textwrap.indent(deprecation_msg, 6 * " "))

        if field.description is not None:
            doc.append("")
            doc.append(f"{textwrap.indent(field.description, '   ')}")

    lines[:] = doc


def _process_settings_method(app: Sphinx, method: MethodType, lines: list[str]) -> None:
    sphinx_adds_type = getattr(app.config, "autodoc_typehints", None) in {"description", "both"}
    ext_adds_type = "sphinx_autodoc_typehints" in app.extensions
    add_annot = not sphinx_adds_type and not ext_adds_type
    match method.__name__:
        case "override":
            _process_settings_method_override(app, method, lines, add_annot=add_annot)
        case "reset":
            _process_settings_method_reset(app, method, lines, add_annot=add_annot)


def _process_settings_method_override(app: Sphinx, method: MethodType, lines: list[str], *, add_annot: bool) -> None:
    settings = cast("Settings", method.__self__)
    params: list[Block] = [
        Block.Parameter(
            Parameter(
                [fname],
                type_annotation=type_str(type(settings), field) if add_annot else None,
                description=field.description,
            )
        )
        for fname, field in type(settings).model_fields.items()
    ]
    model = Docstring(
        summary="Provides local override via keyword arguments as a context manager.",
        sections=[Section(SectionKind.PARAMETERS, blocks=params)],
    )
    _emit_docstring(app, model, lines)


def _process_settings_method_reset(app: Sphinx, method: MethodType, lines: list[str], *, add_annot: bool) -> None:
    settings = cast("Settings", method.__self__)

    annot = f"typing.Literal[{', '.join(settings.model_fields.keys())}]" if add_annot else None
    desc = "Names of settings to reset."
    names_param = Parameter(["names"], type_annotation=annot, description=desc, is_optional=True)
    model = parse("\n".join(lines)).to_model()
    model.sections = [Section(SectionKind.PARAMETERS, blocks=[Block.Parameter(names_param)])]
    _emit_docstring(app, model, lines)


_namespace_decorator_summary_template = (
    "Decorator for registering custom functionality with a :class:`~{qualname}` object."
)
_namespace_decorator_extended_summary_template = """This decorator allows you to extend {name} objects with custom methods and properties
organized under a namespace. The namespace becomes accessible as an attribute on {name}
instances, providing a clean way to you to add domain-specific functionality without modifying
the {name} class itself, or extending the class with additional methods as you see fit in your workflow."""
_namespace_decorator_argument_description_template = """Name under which the accessor should be registered. This will be the attribute name
used to access your namespace's functionality on {name} objects (e.g., `instance.name`).
Cannot conflict with existing {name} attributes. The list of reserved attributes includes
everything outputted by `dir({name})`."""
_namespace_decorator_notes_template = """Implementation requirements:

1. The decorated class must have an `__init__` method that accepts exactly one parameter
   (besides `self`) named `{canonical_instance_name}` and annotated with type :class:`~{qualname}`.
2. The namespace will be initialized with the {name} object on first access and then
   cached on the instance.
3. If the namespace name conflicts with an existing namespace, a warning is issued.
4. If the namespace name conflicts with a built-in {name} attribute, an AttributeError is raised.",
"""
_namespace_decorator_examples_template = """>>> @{decorator_name}("do_something")
... class DoSomething:
...     def __init__(self, {canonical_instance_name}: {name}):
...         self._obj = {canonical_instance_name}
...
...     def has_foo(self) -> bool:
...         return hasattr(self._obj, "foo")
>>>
>>> # Create a {name} object
>>> obj = {name}()
>>>
>>> # use the registered namespace
>>> obj.do_something.has_foo()
False
"""


def _process_namespace_decorator(app: Sphinx, name: str, info: _NSInfo, lines: list[str]) -> None:
    qualname = f"{info.cls.__module__}.{info.cls.__name__}"
    model = Docstring(
        summary=_namespace_decorator_summary_template.format(qualname=qualname),
        extended_summary=_namespace_decorator_extended_summary_template.format(name=info.cls.__name__),
        sections=[
            Section(
                SectionKind.PARAMETERS,
                blocks=[
                    Block.Parameter(
                        Parameter(
                            names=["name"],
                            description=_namespace_decorator_argument_description_template.format(
                                name=info.cls.__name__
                            ),
                        )
                    )
                ],
            ),
            Section(
                SectionKind.RETURNS,
                blocks=[
                    Block.Return(
                        Return(description="A decorator that registers the decorated class as a custom namespace.")
                    )
                ],
            ),
            Section(
                SectionKind.NOTES,
                blocks=[
                    Block.Paragraph(
                        _namespace_decorator_notes_template.format(
                            qualname=qualname, name=info.cls.__name__, canonical_instance_name=info.name
                        )
                    )
                ],
            ),
            Section(
                SectionKind.EXAMPLES,
                blocks=[
                    Block.Paragraph(
                        _namespace_decorator_examples_template.format(
                            decorator_name=_get_objname(name), name=info.cls.__name__, canonical_instance_name=info.name
                        )
                    )
                ],
            ),
        ],
    )

    _emit_docstring(app, model, lines)
