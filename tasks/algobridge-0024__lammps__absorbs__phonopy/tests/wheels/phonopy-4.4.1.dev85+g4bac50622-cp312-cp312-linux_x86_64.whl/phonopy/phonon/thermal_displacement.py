# SPDX-License-Identifier: BSD-3-Clause
"""Calculations of thermal displacements."""

from __future__ import annotations

import os
from collections.abc import Sequence
from typing import Any, Literal, TypedDict

import numpy as np
from numpy.typing import NDArray

from phonopy.interface.cif import write_cif_P1
from phonopy.phonon.mesh import IterMesh, Mesh
from phonopy.physical_units import get_physical_units
from phonopy.structure.atoms import PhonopyAtoms


class ThermalDisplacementMatricesDict(TypedDict):
    """Return type of Phonopy.get_thermal_displacement_matrices_dict."""

    temperatures: NDArray[np.double] | None
    thermal_displacement_matrices: NDArray[np.double] | None
    thermal_displacement_matrices_cif: NDArray[np.double] | None


class ThermalMotion:
    """Base class of thermal displacement calculation classes."""

    def __init__(
        self,
        iter_mesh: IterMesh | Mesh,
        freq_min: float | None = None,
        freq_max: float | None = None,
    ) -> None:
        """Init method."""
        self._iter_mesh = iter_mesh
        if freq_min is None:
            self._fmin: float = 0.0
        else:
            self._fmin = freq_min
        if freq_max is None:
            self._fmax = None
        else:
            self._fmax = freq_max

        masses = iter_mesh.dynamical_matrix.primitive.masses
        assert masses is not None
        self._masses = masses * get_physical_units().AMU
        self._masses3 = (
            np.array([[m] * 3 for m in masses]).ravel() * get_physical_units().AMU
        )
        self._temperatures: NDArray[np.double] | None = None

    def _get_Q2(
        self, freq: float, t: NDArray[np.double]
    ) -> NDArray[np.double]:  # freq in THz
        return (
            get_physical_units().Hbar
            * get_physical_units().EV
            / get_physical_units().Angstrom ** 2
            * ((self._get_population(freq, t) + 0.5) / (freq * 1e12 * 2 * np.pi))
        )

    @property
    def temperatures(self) -> NDArray[np.double] | None:
        """Setter and getter of temperatures."""
        return self._temperatures

    @temperatures.setter
    def temperatures(self, temperatures: Sequence[float] | NDArray[np.double]) -> None:
        t_array = np.array(temperatures, dtype="double")
        condition = np.logical_not(t_array < 0)
        self._temperatures = np.extract(condition, t_array).astype("double")

    def set_temperature_range(
        self,
        t_min: float | None = None,
        t_max: float | None = None,
        t_step: float | None = None,
    ) -> None:
        """Set temperatures by range."""
        if t_min is None:
            _t_min: float = 10.0
        elif t_min < 0:
            _t_min = 0.0
        else:
            _t_min = t_min

        if t_max is None:
            _t_max: float = 1000.0
        elif t_max > _t_min:
            _t_max = t_max
        else:
            _t_max = _t_min

        if t_step is None:
            _t_step: float = 10.0
        elif t_step > 0:
            _t_step = t_step
        else:
            _t_step = 10.0

        self._temperatures = np.arange(
            _t_min, _t_max + _t_step / 2.0, _t_step, dtype="double"
        )

    def _get_population(
        self,
        freq: float,
        t: Sequence[float] | NDArray[np.double],
    ) -> NDArray[np.double]:  # freq in THz
        """Return phonon population number."""
        t_array = np.asarray(t, dtype="double")
        vals = np.zeros_like(t_array, dtype="double")
        condition = t_array > 1.0
        vals[condition] = 1.0 / (
            np.exp(
                freq
                * get_physical_units().THzToEv
                / (get_physical_units().KB * t_array[condition])
            )
            - 1
        )
        return vals


class ThermalDisplacements(ThermalMotion):
    """Class to calculate thermal displacements (mean square displacements).

    Attributes
    ----------
    thermal_displacements : ndarray
        With `projection_direction` is `None`
            shape=(temps, natoms * 3), dtype=float
        otherwise
            shape=(temps, natoms), dtype=float

    """

    def __init__(
        self,
        iter_mesh: IterMesh | Mesh,
        projection_direction: NDArray[np.double] | Sequence[float] | None = None,
        freq_min: float | None = None,
        freq_max: float | None = None,
    ) -> None:
        """Init method.

        Parameters
        ----------
        iter_mesh:
            Mesh or IterMesh instance. Grid points must not be reduced by
            symmetry, i.e., IterMesh instance has to be create
            ``is_mesh_symmetry=False``.
        projection_direction:
            Eigenvector projection direction in Cartesian
            coordinates. If None, eigenvector is not projected.
        freq_min:
            Minimum phonon frequency to determine whether include or not.
        freq_max:
            Maximum phonon frequency to determine whether include or not.

        """
        super().__init__(iter_mesh, freq_min=freq_min, freq_max=freq_max)
        if projection_direction is None:
            self._projection_direction = None
        else:
            projection_direction = np.array(projection_direction, dtype="double")
            self._projection_direction = projection_direction / np.linalg.norm(
                projection_direction
            )
        self._displacements: NDArray[np.double] | None = None
        self._eigenvectors: NDArray[np.cdouble] | None = None
        self._p_eigenvectors: NDArray[np.cdouble] | None = None

    @property
    def thermal_displacements(self) -> NDArray[np.double] | None:
        """Return thermal displacements."""
        return self._displacements

    def run(self) -> None:
        """Calculate thermal displacements."""
        if self._projection_direction is not None:
            masses = self._masses
        else:
            masses = self._masses3
        temps = self._temperatures
        assert temps is not None
        disps = np.zeros((len(temps), len(masses)), dtype=float)

        count = 0
        for count, (fs, vecs) in enumerate(self._iter_mesh):  # noqa B007
            assert vecs is not None
            if self._projection_direction is not None:
                p_vecs = np.dot(
                    vecs.T.reshape(-1, 3), self._projection_direction
                ).reshape(-1, len(masses))
                vecs2 = np.abs(p_vecs) ** 2 / masses
            else:
                vecs2 = (abs(vecs) ** 2).T / masses

            valid_indices = fs > self._fmin
            if self._fmax is not None:
                valid_indices *= fs < self._fmax

            for f, v2 in zip(fs[valid_indices], vecs2[valid_indices], strict=True):
                disps += np.outer(self._get_Q2(f, temps), v2)

        assert np.prod(self._iter_mesh.mesh_numbers) == count + 1
        self._displacements = disps / (count + 1)

    def write_yaml(
        self, filename: str | os.PathLike = "thermal_displacements.yaml"
    ) -> None:
        """Write results to file in yaml."""
        assert self._temperatures is not None
        assert self._displacements is not None
        natom = len(self._masses)
        lines = []
        lines.append("# Thermal displacements")
        lines.append("natom: %5d" % (natom))
        lines.append("freq_min: %f" % self._fmin)

        lines.append("thermal_displacements:")
        for t, u in zip(self._temperatures, self._displacements, strict=True):
            lines.append("- temperature:   %15.7f" % t)
            lines.append("  displacements:")
            for i, elems in enumerate(np.reshape(u, (natom, -1))):
                text = "  - [ %10.7f" % elems[0]
                for j in range(len(elems) - 1):
                    text += ", %10.7f" % elems[j + 1]
                text += " ] # atom %d" % (i + 1)
                lines.append(text)

        with open(filename, "w") as w:
            w.write("\n".join(lines))

    def plot(self, ax: Any, is_legend: bool = False) -> None:
        """Plot thermal displacements into matplotlib axes.

        Parameters
        ----------
        ax : matplotlib.axes.Axes
            Single Matplotlib Axes object.
        is_legend : bool, optional
            Show legend when True. Default is False.

        """
        assert self._displacements is not None
        assert self._temperatures is not None
        xyz = ["x", "y", "z"]
        for i, u in enumerate(self._displacements.transpose()):
            ax.plot(self._temperatures, u, label=("%d-%s" % (i // 3 + 1, xyz[i % 3])))

        if is_legend:
            ax.legend(loc="upper left")

    def _project_eigenvectors(self) -> None:
        """Project eigenvectors to specific direction.

        Eigenvectors are projected along Cartesian direction.

        """
        assert self._eigenvectors is not None
        assert self._projection_direction is not None
        p_eigenvectors: list[NDArray[np.cdouble]] = []
        for vecs_q in self._eigenvectors:
            p_vecs_q = []
            for vecs in vecs_q.T:
                p_vecs_q.append(np.dot(vecs.reshape(-1, 3), self._projection_direction))
            p_eigenvectors.append(np.transpose(p_vecs_q))
        self._p_eigenvectors = np.array(p_eigenvectors)


class ThermalDisplacementMatrices(ThermalMotion):
    """Class to calculate thermal displacement (mean square displacement) matrices."""

    def __init__(
        self,
        iter_mesh: IterMesh | Mesh,
        freq_min: float | None = None,
        freq_max: float | None = None,
        lattice: NDArray[np.double] | None = None,
    ) -> None:
        """Init method.

        Parameters
        ----------
        iter_mesh:
            Mesh or IterMesh instance. Grid points must not be reduced by
            symmetry, i.e., IterMesh instance has to be create
            ``is_mesh_symmetry=False``.
        freq_min: float
            Minimum phonon frequency to determine whether include or not.
        freq_max: float
            Maximum phonon frequency to determine whether include or not.
        lattice: array_like
            Lattice parameters (column vectors) in real space
            dtype='double', shape=(3, 3)

        """
        super().__init__(iter_mesh, freq_min=freq_min, freq_max=freq_max)
        self._disp_matrices: NDArray[np.double] | None = None
        self._disp_matrices_cif: NDArray[np.double] | None = None

        self._ANinv: NDArray[np.double] | None
        if lattice is not None:
            A = lattice
            N = np.diag([np.linalg.norm(x) for x in np.linalg.inv(A)])
            self._ANinv = np.linalg.inv(np.dot(A, N))
        else:
            self._ANinv = None

    @property
    def thermal_displacement_matrices(self) -> NDArray[np.double] | None:
        """Return thermal displacement matrices."""
        return self._disp_matrices

    @property
    def thermal_displacement_matrices_cif(self) -> NDArray[np.double] | None:
        """Return thermal displacement matrices in cif definition."""
        return self._disp_matrices_cif

    def run(
        self,
        np_overflow: Literal["ignore", "warn", "raise", "call", "print", "log"]
        | None = None,
    ) -> None:
        """Calculate thermal displacement matrices.

        Parameters
        ----------
        np_overflow: str or None
            Switch of error handling of numpy. 'raise' to see which phonon it is.

        """
        np.seterr(over=np_overflow)
        self._get_disp_matrices()
        np.seterr(over=None)

        if self._ANinv is not None:
            assert self._disp_matrices is not None
            self._disp_matrices_cif = np.zeros(
                self._disp_matrices.shape, dtype="double"
            )
            for i, matrices in enumerate(self._disp_matrices):
                for j, mat in enumerate(matrices):
                    mat_cif = np.dot(np.dot(self._ANinv, mat), self._ANinv.T)
                    self._disp_matrices_cif[i, j] = mat_cif

        self._get_disp_matrices()

    def _get_disp_matrices(self) -> None:
        dtype_complex = np.cdouble
        assert self._temperatures is not None
        disps = np.zeros(
            (len(self._temperatures), len(self._masses), 3, 3), dtype=dtype_complex
        )
        count = 0
        for count, (freqs, eigvecs) in enumerate(self._iter_mesh):  # noqa B007
            assert eigvecs is not None
            valid_indices = freqs > self._fmin
            if self._fmax is not None:
                valid_indices *= freqs < self._fmax
            for i_band, (f, vec) in enumerate(
                zip(freqs[valid_indices], (eigvecs.T)[valid_indices], strict=True)
            ):
                c = np.zeros((len(self._masses), 3, 3), dtype=dtype_complex, order="C")
                for i, (v, m) in enumerate(
                    zip(vec.reshape(-1, 3), self._masses, strict=True)
                ):
                    c[i] = np.outer(v, v.conj()) / m

                # for i, t in enumerate(self._temperatures):
                #     try:
                #         disps[i] += self._get_Q2(f, t) * np.array(c)
                #     except FloatingPointError as e:
                #         # Probably, overflow in exp(freq / (KB * T))
                #         print("%s: T=%.1f freq=%.2f (band #%d)" %
                #               (e, t, f, i_band))
                try:
                    Q2 = np.array(self._get_Q2(f, self._temperatures), dtype="double")
                    disps += Q2[:, None, None, None] * c[None, :, :, :]
                except FloatingPointError as e:
                    # Probably, overflow in exp(freq / (KB * T))
                    print("%s: freq=%.2f (band #%d)" % (e, f, i_band))

        assert np.prod(self._iter_mesh.mesh_numbers) == count + 1
        assert (abs(disps.imag) < 1e-10).all()
        self._disp_matrices = disps.real / (count + 1)

    def write_cif(
        self,
        cell: PhonopyAtoms,
        temperature_index: int,
        filename: str | os.PathLike = "tdispmat.cif",
    ) -> None:
        """Write results to file in P1 symmetry CIF format."""
        assert self._disp_matrices_cif is not None
        write_cif_P1(
            cell,
            U_cif=self._disp_matrices_cif[temperature_index],
            filename=filename,
        )

    def write_yaml(
        self, filename: str | os.PathLike = "thermal_displacement_matrices.yaml"
    ) -> None:
        """Write results to file in yaml."""
        assert self._temperatures is not None
        assert self._disp_matrices is not None
        natom = len(self._masses)
        lines = []

        lines.append("# Thermal displacement_matrices")
        lines.append("natom: %5d" % (natom))
        lines.append("freq_min: %f" % self._fmin)
        lines.append("thermal_displacement_matrices:")
        for i, t in enumerate(self._temperatures):
            matrices = self._disp_matrices[i]
            lines.append("- temperature:   %15.7f" % t)
            lines.append("  displacement_matrices:")
            for j, mat in enumerate(matrices):
                # For checking imaginary part that should be zero
                # lines.append("  - # atom %d" % (i + 1))
                # for v in mat:
                #     lines.append(
                #         "    [ %8.5f, %8.5f, %8.5f, %8.5f, %8.5f, %8.5f ]"
                #         % (tuple(v.real) + tuple(v.imag)))
                m = mat
                lines.append(
                    ("  - [ " + "%8.5f, " * 5 + "%8.5f ] # atom %d")
                    % (m[0, 0], m[1, 1], m[2, 2], m[1, 2], m[0, 2], m[0, 1], j + 1)
                )
            if self._ANinv is not None:
                assert self._disp_matrices_cif is not None
                matrices_cif = self._disp_matrices_cif[i]
                lines.append("  displacement_matrices_cif:")
                for j, mat_cif in enumerate(matrices_cif):
                    m = mat_cif
                    lines.append(
                        ("  - [ " + "%8.5f, " * 5 + "%8.5f ] # atom %d")
                        % (m[0, 0], m[1, 1], m[2, 2], m[1, 2], m[0, 2], m[0, 1], j + 1)
                    )

        with open(filename, "w") as w:
            w.write("\n".join(lines))
