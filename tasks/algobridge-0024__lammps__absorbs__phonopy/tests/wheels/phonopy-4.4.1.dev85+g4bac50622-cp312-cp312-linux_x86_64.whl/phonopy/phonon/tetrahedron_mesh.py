# SPDX-License-Identifier: BSD-3-Clause
"""Linear tetrahedron method on regular grid."""

# copyright (C) 2013 Atsushi Togo
from __future__ import annotations

from collections.abc import Iterator
from typing import Literal

import numpy as np
from numpy.typing import NDArray

from phonopy.phonon.tetrahedron_method import TetrahedronMethod
from phonopy.structure.atoms import PhonopyAtoms


class TetrahedronMesh:
    """Class to perform linear tetrahedron method on regular grid."""

    def __init__(
        self,
        cell: PhonopyAtoms,
        frequencies: NDArray[np.double],  # only at ir-grid-points
        mesh: list[int] | NDArray[np.int64],
        grid_address: NDArray[np.int64],
        grid_mapping_table: NDArray[np.int64],
        ir_grid_points: NDArray[np.int64],
        grid_order: list[int] | None = None,
        lang: Literal["C", "Python", "Rust"] = "Rust",
    ) -> None:
        """Linear tetrahedron method on uniform mesh for phonons.

        Parameters
        ----------
        cell : PhonopyAtoms
            Primitive cell used to calculate frequencies
        frequencies: ndarray
            Phonon frequencies on ir-grid points
            shape=(num_ir_grid_points, num_band)
            dtype='double'
        mesh : ndarray or list of int
            Mesh numbers for grids
            shape=(3,)
            dtype='int64'
        grid_address : ndarray
            Addresses of all grid points given by GridPoints class.
            shape=(prod(mesh), 3)
            dtype='int64'
        grid_mapping_table : ndarray
            Mapping of grid points to irreducible grid points given by
            GridPoints class.
            shape=(prod(mesh),)
            dtype='int64'
        ir_grid_points : ndarray
            Irreducible grid points given by GridPoints class.
            shape=(len(np.unique(grid_mapping_table)),)
            dtype='int64'
        grid_order : list of int, optional
            This controls how grid addresses are stored either C style or
            Fortran style.
        lang : str, 'C' or else, optional
            With 'C', C implementation is used. Otherwise Python implementation
            runs.

        """
        self._cell = cell
        self._frequencies = frequencies
        self._mesh = np.array(mesh, dtype="int64")
        self._grid_address = grid_address
        self._grid_mapping_table = grid_mapping_table
        self._lang: Literal["C", "Python", "Rust"] = lang
        if lang in ("C", "Rust"):
            self._grid_order = None
        else:
            if grid_order is None:
                self._grid_order = [1, mesh[0], mesh[0] * mesh[1]]
            else:
                self._grid_order = grid_order
        self._ir_grid_points = ir_grid_points

        self._tm: TetrahedronMethod | None = None
        self._gp_ir_index: NDArray[np.int64]
        self._integration_weights: NDArray[np.double]
        self._relative_grid_address: NDArray[np.int64]
        self._frequency_points: NDArray[np.double]
        self._value: Literal["I", "J"]

        self._grid_point_count = 0

        self._prepare()

    def __iter__(self) -> Iterator[NDArray[np.double]]:
        """Define iterator over grid points."""
        return self

    def __next__(self) -> NDArray[np.double]:
        """Perform linear tetrahedron method at a grid point."""
        if self._tm is None:
            raise RuntimeError("Tetrahedron method is not set yet.")
        if self._grid_point_count == len(self._ir_grid_points):
            raise StopIteration
        else:
            gp = self._ir_grid_points[self._grid_point_count]
            tetrahedra_frequencies = get_tetrahedra_frequencies(
                gp,
                self._mesh,
                self._grid_address,
                self._relative_grid_address,
                self._gp_ir_index,
                self._frequencies,
                grid_order=self._grid_order,
                lang=self._lang,
            )
            for ib, frequencies in enumerate(tetrahedra_frequencies):
                self._tm.set_tetrahedra_omegas(frequencies)
                self._tm.run(self._frequency_points, value=self._value)
                iw = self._tm.get_integration_weight()
                self._integration_weights[:, ib] = iw
            self._integration_weights /= np.prod(self._mesh)
            self._grid_point_count += 1
            return self._integration_weights

    def get_integration_weights(self) -> NDArray[np.double]:
        """Return integration weights."""
        if self._integration_weights is None:
            raise RuntimeError("Integration weights are not calculated yet.")
        return self._integration_weights

    def get_frequency_points(self) -> NDArray[np.double]:
        """Return frequency points."""
        if self._frequency_points is None:
            raise RuntimeError("Frequency points are not set yet.")
        return self._frequency_points

    def set(
        self,
        value: Literal["I", "J"] = "I",
        division_number: int = 201,
        frequency_points: NDArray[np.double] | None = None,
        lang: Literal["C", "Python", "Rust"] = "Rust",
    ) -> None:
        """Prepare environment to perform linear tetrahedron method."""
        self._grid_point_count = 0
        self._value: Literal["I", "J"] = value
        if frequency_points is None:
            max_frequency = np.amax(self._frequencies)
            min_frequency = np.amin(self._frequencies)
            self._frequency_points = np.linspace(
                min_frequency, max_frequency, division_number, dtype="double"
            )
        else:
            self._frequency_points = np.array(frequency_points, dtype="double")

        num_band = self._frequencies.shape[1]
        num_freqs = len(self._frequency_points)
        self._integration_weights = np.zeros((num_freqs, num_band), dtype="double")
        self._tm = TetrahedronMethod(
            np.linalg.inv(self._cell.cell), mesh=self._mesh, lang=lang
        )
        self._relative_grid_address = self._tm.tetrahedra

    def _prepare(self) -> None:
        ir_gp_indices = {}
        for i, gp in enumerate(self._ir_grid_points):
            ir_gp_indices[gp] = i

        self._gp_ir_index = np.zeros_like(self._grid_mapping_table)
        for i, gp in enumerate(self._grid_mapping_table):
            self._gp_ir_index[i] = ir_gp_indices[gp]


def get_tetrahedra_frequencies(
    gp: int,
    mesh: NDArray[np.int64],
    grid_address: NDArray[np.int64],
    relative_grid_address: NDArray[np.int64],
    gp_ir_index: NDArray[np.int64],
    frequencies: NDArray[np.double],
    grid_order: list[int] | None = None,
    lang: Literal["C", "Python", "Rust"] = "Rust",
) -> NDArray[np.double]:
    """Return frequencies on the relative_grid_addresses.

    Note
    ----
    This implementation is based on GR-grid.

    Parameters
    ----------
    gp : float
        Grid index
    mesh : ndarray
        Mesh numbers. shape=(3, ), dtype='int64'
    grid_address : ndarray
        Grid address in integers. shape=(prod(mesh), 3), dtype='int64', order='C'
    relative_grid_addresses : ndarray
        Relative grid addresses from the centre (i.e., gp) shape=(24, 4, 3),
        dtype='int64', order='C'
    gp_ir_index : ndarray
        Mapping table from grid index in GR-grid to index corresponding to first
        dimension of frequencies. The ir-grid index is
        range(len(ir-grid-points)). shape=(prod(mesh), ), dtype='int64'
    frequencies : ndarray
        Phonon frequencies on ir-grid points. shape=(ir-grid-points, num_band)
        dtype='double'
    grid_order : list of int, optional
        This controls how grid addresses are stored either C style or Fortran
        style. This is only valid when lang != 'C'.
    lang : str, 'C' or else, optional
        With 'C', C implementation is used. Otherwise Python implementation
        runs.

    Returns
    -------
    ndarray
        Frequencies at tetheredra tertices. shape=(num_bands, 24, 4),
        dtype='double', order='C'

    """
    if lang in ("C", "Rust"):
        try:
            import phonopy._phonopy as phonoc  # noqa F401

            return _get_tetrahedra_frequencies_C(
                gp, mesh, grid_address, relative_grid_address, gp_ir_index, frequencies
            )
        except ImportError:
            assert grid_order is not None
            return _get_tetrahedra_frequencies_Py(
                gp,
                mesh,
                grid_address,
                relative_grid_address,
                gp_ir_index,
                frequencies,
                grid_order,
            )
    else:
        assert grid_order is not None
        return _get_tetrahedra_frequencies_Py(
            gp,
            mesh,
            grid_address,
            relative_grid_address,
            gp_ir_index,
            frequencies,
            grid_order,
        )


def _get_tetrahedra_frequencies_C(
    gp: int,
    mesh: NDArray[np.int64],
    grid_address: NDArray[np.int64],
    relative_grid_address: NDArray[np.int64],
    gp_ir_index: NDArray[np.int64],
    frequencies: NDArray[np.double],
) -> NDArray[np.double]:
    import phonopy._phonopy as phonoc

    t_frequencies = np.zeros((1, frequencies.shape[1], 24, 4), dtype="double")
    phonoc.tetrahedra_frequencies(
        t_frequencies,
        np.array([gp], dtype="int64"),
        mesh,
        grid_address,
        gp_ir_index,
        relative_grid_address,
        frequencies,
    )
    return np.array(t_frequencies[0], dtype="double", order="C")


def _get_tetrahedra_frequencies_Py(
    gp: int,
    mesh: NDArray[np.int64],
    grid_address: NDArray[np.int64],
    relative_grid_address: NDArray[np.int64],
    gp_ir_index: NDArray[np.int64],
    frequencies: NDArray[np.double],
    grid_order: list[int],
) -> NDArray[np.double]:
    t_frequencies = np.zeros((frequencies.shape[1], 24, 4), dtype="double")
    for i, t in enumerate(relative_grid_address):
        address = t + grid_address[gp]
        neighbors = np.dot(address % mesh, grid_order)
        t_frequencies[:, i, :] = frequencies[gp_ir_index[neighbors]].T
    return t_frequencies
