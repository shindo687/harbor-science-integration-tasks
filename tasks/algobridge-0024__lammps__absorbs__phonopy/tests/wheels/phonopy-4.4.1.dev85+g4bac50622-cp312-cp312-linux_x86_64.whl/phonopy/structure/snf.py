# SPDX-License-Identifier: BSD-3-Clause
"""Calculation of Smith normal form of 3x3 matrix."""

from __future__ import annotations

from collections.abc import Sequence

import numpy as np
from numpy.typing import NDArray


#
# Smith normal form for 3x3 integer matrix
# This code is maintained at https://github.com/atztogo/snf3x3.
#
class SNF3x3:
    """Smith normal form for 3x3 matrix.

    Input 3x3 integer matrix A is transformed to 3x3 diagonal integer
    matrix (D) by two 3x3 integer matrices P and Q, which is written as

        D = PAQ

    with abs(det(A)) = det(D), det(P) = 1, det(Q) = sgn(det(A)).

    The algorithm is implemented following
    https://en.wikipedia.org/wiki/Smith_normal_form,
    but the diagonal elements don't follow the rule of it.

    Usage
    -----
    snf = SNF3x3(int_mat)
    snf.run()

    Attributes
    ----------
    D, P, Q : ndarray
        These 3x3 integer matrices explained above.
        shape=(3, 3), dtype='int64'

    """

    def __init__(self, A: Sequence[Sequence[int]] | NDArray[np.int64]) -> None:
        """Init method.

        Parameters
        ----------
        A : array_like
            3x3 integer matrix.
            shape=(3, 3)

        """
        self._A_orig: NDArray[np.int64] = np.array(A, dtype="int64", order="C")
        self._A: NDArray[np.int64] = np.array(A, dtype="int64", order="C")
        self._Ps: list[NDArray[np.int64]] = []
        self._Qs: list[NDArray[np.int64]] = []
        self._L: list[NDArray[np.int64]] = []
        self._P: NDArray[np.int64]
        self._Q: NDArray[np.int64]
        self._D: NDArray[np.int64]
        self._attempt: int = 0

        self._run()

    def _run(self) -> None:
        """Calculate SNF."""
        for _ in self:
            pass

        A = np.dot(self._P, np.dot(self._A_orig, self._Q))
        assert (A == self._A).all()

    def __iter__(self) -> SNF3x3:
        """Define iterator over calculation steps."""
        return self

    def __next__(self) -> int:
        """Calculate an algorithm step."""
        self._attempt += 1
        if self._first():
            if self._second():
                self._finalize()
                raise StopIteration
        return self._attempt

    @property
    def A(self) -> NDArray[np.int64]:
        """Return A of D = PAQ."""
        return self._A

    @property
    def D(self) -> NDArray[np.int64]:
        """Return D of D = PAQ."""
        return self._D

    @property
    def P(self) -> NDArray[np.int64]:
        """Return P of D = PAQ."""
        return self._P

    @property
    def Q(self) -> NDArray[np.int64]:
        """Return Q of D = PAQ."""
        return self._Q

    def _first(self) -> bool:
        self._first_one_loop()
        A = self._A
        if A[1, 0] == 0 and A[2, 0] == 0:
            return True
        elif A[1, 0] % A[0, 0] == 0 and A[2, 0] % A[0, 0] == 0:
            self._first_finalize()
            self._Ps += self._L
            self._L = []
            return True
        else:
            return False

    def _first_one_loop(self) -> None:
        self._first_column()
        self._Ps += self._L
        self._L = []
        self._A[:] = self._A.T
        self._first_column()
        self._Qs += self._L
        self._L = []
        self._A[:] = self._A.T

    def _first_column(self) -> None:
        i = self._search_first_pivot()
        if i > 0:
            self._swap_rows(0, i)
        if i < 0:
            raise RuntimeError("Determinant is 0.")

        if self._A[1, 0] != 0:
            self._zero_first_column(1)
        if self._A[2, 0] != 0:
            self._zero_first_column(2)

    def _zero_first_column(self, j: int) -> None:
        A = self._A
        r, s, t = xgcd([A[0, 0], A[j, 0]])
        self._set_zero(0, j, A[0, 0], A[j, 0], r, s, t)

    def _search_first_pivot(self) -> int:
        for i in range(3):  # column index
            if self._A[i, 0] != 0:
                return i
        return -1

    def _first_finalize(self) -> None:
        """Set zeros along the first column except for A[0, 0].

        This is possible only when A[1,0] and A[2,0] are dividable by A[0,0].

        """
        A = self._A
        L = np.eye(3, dtype="int64", order="C")
        L[1, 0] = -A[1, 0] // A[0, 0]
        L[2, 0] = -A[2, 0] // A[0, 0]
        self._L.append(L.copy())
        self._A[:] = np.dot(L, self._A)

    def _second(self) -> bool:
        """Find Smith normal form for Right-low 2x2 matrix."""
        self._second_one_loop()
        A = self._A
        if A[2, 1] == 0:
            return True
        elif A[2, 1] % A[1, 1] == 0:
            self._second_finalize()
            self._Ps += self._L
            self._L = []
            return True
        else:
            return False

    def _second_one_loop(self) -> None:
        self._second_column()
        self._Ps += self._L
        self._L = []
        self._A[:] = self._A.T
        self._second_column()
        self._Qs += self._L
        self._L = []
        self._A[:] = self._A.T

    def _second_column(self) -> None:
        """Right-low 2x2 matrix.

        Assume elements in first row and column are all zero except for A[0,0].

        """
        if self._A[1, 1] == 0 and self._A[2, 1] != 0:
            self._swap_rows(1, 2)

        if self._A[2, 1] != 0:
            self._zero_second_column()

    def _zero_second_column(self) -> None:
        A = self._A
        r, s, t = xgcd([A[1, 1], A[2, 1]])
        self._set_zero(1, 2, A[1, 1], A[2, 1], r, s, t)

    def _second_finalize(self) -> None:
        """Set zero at A[2, 1].

        This is possible only when A[2,1] is dividable by A[1,1].

        """
        A = self._A
        L = np.eye(3, dtype="int64")
        L[2, 1] = -A[2, 1] // A[1, 1]
        self._L.append(L.copy())
        self._A[:] = np.dot(L, self._A)

    def _finalize(self) -> None:
        for i in range(3):
            if self._A[i, i] < 0:
                self._flip_sign_row(i)
                self._Ps += self._L
                self._L = []
        self._finalize_sort()
        self._finalize_disturb(0, 1)
        self._first()
        self._finalize_sort()
        self._finalize_disturb(1, 2)
        self._second()
        self._set_PQ()

    def _finalize_sort(self) -> None:
        if self._A[0, 0] > self._A[1, 1]:
            self._swap_diag_elems(0, 1)
        if self._A[1, 1] > self._A[2, 2]:
            self._swap_diag_elems(1, 2)
        if self._A[0, 0] > self._A[1, 1]:
            self._swap_diag_elems(0, 1)

    def _finalize_disturb(self, i: int, j: int) -> None:
        if self._A[j, j] % self._A[i, i] != 0:
            self._A[:] = self._A.T
            self._disturb_rows(i, j)
            self._Qs += self._L
            self._L = []
            self._A[:] = self._A.T

    def _disturb_rows(self, i: int, j: int) -> None:
        L = np.eye(3, dtype="int64", order="C")
        L[i, i] = 1
        L[i, j] = 1
        L[j, i] = 0
        L[j, j] = 1
        self._L.append(L.copy())
        self._A[:] = np.dot(L, self._A)

    def _swap_diag_elems(self, i: int, j: int) -> None:
        self._swap_rows(i, j)
        self._Ps += self._L
        self._L = []
        self._A[:] = self._A.T
        self._swap_rows(i, j)
        self._Qs += self._L
        self._L = []
        self._A[:] = self._A.T

    def _swap_rows(self, i: int, j: int) -> None:
        """Swap i and j rows.

        As the side effect, determinant flips.

        """
        L = np.eye(3, dtype="int64")
        L[i, i] = 0
        L[j, j] = 0
        L[i, j] = 1
        L[j, i] = 1
        self._L.append(L.copy())
        self._A[:] = np.dot(L, self._A)

    def _flip_sign_row(self, i: int) -> None:
        """Multiply -1 for all elements in row."""
        L = np.eye(3, dtype="int64")
        L[i, i] = -1
        self._L.append(L.copy())
        self._A[:] = np.dot(L, self._A)

    def _set_zero(self, i: int, j: int, a: int, b: int, r: int, s: int, t: int) -> None:
        """Let A[i, j] be zero based on Bezout's identity.

        [ii ij]
        [ji jj] is a (k,k) minor of original 3x3 matrix.

        """
        L = np.eye(3, dtype="int64")
        L[i, i] = s
        L[i, j] = t
        L[j, i] = -b // r
        L[j, j] = a // r
        self._L.append(L.copy())
        self._A[:] = np.dot(L, self._A)

    def _set_PQ(self) -> None:
        P = np.eye(3, dtype="int64")
        for _P in self._Ps:
            P = np.dot(_P, P)
        Q = np.eye(3, dtype="int64")
        for _Q in self._Qs:
            Q = np.dot(Q, _Q.T)

        if self._det(P) < 0:
            P *= -1
            Q *= -1

        self._P = P
        self._Q = Q
        self._D = self._A.copy()

    def _det(self, m: NDArray[np.int64]) -> int:
        return int(
            m[0, 0] * (m[1, 1] * m[2, 2] - m[1, 2] * m[2, 1])
            + m[0, 1] * (m[1, 2] * m[2, 0] - m[1, 0] * m[2, 2])
            + m[0, 2] * (m[1, 0] * m[2, 1] - m[1, 1] * m[2, 0])
        )


def xgcd(vals: Sequence[int] | NDArray[np.int64]) -> NDArray[np.int64]:
    """Calculate extended greatest command divisor."""
    _xgcd = Xgcd(vals)
    return _xgcd.run()


class Xgcd:
    """Class to implement extended Euclidean algorithm."""

    def __init__(self, vals: Sequence[int] | NDArray[np.int64]) -> None:
        """Init method."""
        self._vals: NDArray[np.int64] = np.array(vals, dtype="int64")

    def run(self) -> NDArray[np.int64]:
        """Calculate extended GCD."""
        r0, r1 = self._vals
        s0 = 1
        s1 = 0
        t0 = 0
        t1 = 1
        for _ in range(1000):
            r0, r1, s0, s1, t0, t1 = self._step(r0, r1, s0, s1, t0, t1)
            if r1 == 0:
                break

        assert r0 == self._vals[0] * s0 + self._vals[1] * t0

        self._rst: NDArray[np.int64] = np.array([r0, s0, t0], dtype="int64")

        return self._rst

    def _step(
        self, r0: int, r1: int, s0: int, s1: int, t0: int, t1: int
    ) -> tuple[int, int, int, int, int, int]:
        q, m = divmod(r0, r1)
        if m < 0:
            if r1 > 0:
                m += r1
                q -= 1
            if r1 < 0:
                m -= r1
                q += 1
        r2 = m
        s2 = s0 - q * s1
        t2 = t0 - q * t1
        return r1, r2, s1, s2, t1, t2

    def __str__(self) -> str:
        """Show GCD relation."""
        v = self._vals
        r, s, t = self._rst
        return "%d = %d * (%d) + %d * (%d)" % (r, v[0], s, v[1], t)
