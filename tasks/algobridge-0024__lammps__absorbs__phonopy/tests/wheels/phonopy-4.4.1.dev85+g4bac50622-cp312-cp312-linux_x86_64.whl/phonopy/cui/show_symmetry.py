# SPDX-License-Identifier: BSD-3-Clause
"""Show symmetry information invoked by --symmetry command option."""

import numpy as np
import spglib
from numpy.typing import NDArray

try:
    spglib.error.OLD_ERROR_HANDLING = False
except AttributeError:
    pass

from phonopy import Phonopy
from phonopy.cui.collect_cell_info import PhonopyCellInfoResult
from phonopy.interface.calculator import (
    get_default_cell_filename,
    write_crystal_structure,
)
from phonopy.interface.phonopy_yaml import PhonopyYaml
from phonopy.structure.atoms import PhonopyAtoms
from phonopy.structure.cells import (
    argsort_by_key,
    determinant,
    guess_primitive_matrix,
    raise_if_suffixed_symbols,
)
from phonopy.structure.symmetry import Symmetry


def check_symmetry(phonon: Phonopy, cell_info: PhonopyCellInfoResult):
    """Check symmetry of input cell.

    This function first standardizes the input crystal structure based on
    symmetry and determines the primitive cell and unit cell. If
    `supercell_matrix` is not provided, it displays the symmetry information and
    writes it to files. If `supercell_matrix` is specified, the function
    generates a file named `phonopy_supercell.yaml`, which contains details
    about the primitive cell, unit cell, and supercell.

    """
    base_fname = get_default_cell_filename(phonon.calculator)
    symprec = phonon.primitive_symmetry.tolerance
    spglib_cell = spglib.refine_cell(phonon.primitive.totuple(), symprec)
    assert spglib_cell is not None
    bravais_lattice, bravais_pos, bravais_numbers = spglib_cell
    bravais = _rebuild_bravais_cell(
        phonon.primitive,
        np.array(bravais_lattice, dtype="double"),
        np.array(bravais_pos, dtype="double"),
        np.array(bravais_numbers, dtype="int64"),
    )
    trans_mat = guess_primitive_matrix(bravais, symprec=symprec)
    ph = Phonopy(
        bravais,
        supercell_matrix=cell_info.supercell_matrix,
        primitive_matrix=trans_mat,
        calculator=phonon.calculator,
    )

    if (
        cell_info.phonopy_yaml is None
        or cell_info.phonopy_yaml.supercell_matrix is None
    ) and determinant(cell_info.supercell_matrix) > 1:
        print(
            f"Input crystal structure: "
            f'"{cell_info.optional_structure_info.unitcell_filename}"'
        )
        phyml = PhonopyYaml()
        phyml.supercell = ph.supercell
        phyml.supercell_matrix = ph.supercell_matrix
        phyml.primitive = ph.primitive
        phyml.primitive_matrix = ph.primitive_matrix
        with open("phonopy_supercell.yaml", "w") as w:
            print(phyml, file=w)

        print(
            "\n".join(
                [
                    "Standardized primitive cell, unit cell, and supercell have been "
                    "written in ",
                    '"phonopy_supercell.yaml". This file can be read by "phonopy-load" '
                    "command.",
                ]
            )
        )
    else:
        _show_symmetry_yaml(phonon, cell_info, base_fname, ph)


def _rebuild_bravais_cell(
    cell: PhonopyAtoms,
    bravais_lattice: NDArray[np.double],
    bravais_pos: NDArray[np.double],
    bravais_numbers: NDArray[np.int64],
) -> PhonopyAtoms:
    """Rebuild the refined Bravais cell from a spglib ``refine_cell`` result.

    For site-mixture cells ``totuple`` hands species ids (not atomic
    numbers) to spglib, so ``bravais_numbers`` are species ids and the
    species table of ``cell`` must be used to restore symbols, masses, and
    mixture weights (both merged mixtures and weighted species). Ordinary
    cells map the returned atomic numbers directly.

    """
    perm = argsort_by_key(bravais_numbers)
    if cell.is_site_mixture:
        return PhonopyAtoms(
            species_table=cell.species_table,
            species_ids=bravais_numbers[perm],
            scaled_positions=bravais_pos[perm],
            cell=bravais_lattice,
        )
    raise_if_suffixed_symbols(cell)
    return PhonopyAtoms(
        numbers=bravais_numbers[perm],
        scaled_positions=bravais_pos[perm],
        cell=bravais_lattice,
    )


def _show_symmetry_yaml(
    phonon: Phonopy, cell_info: PhonopyCellInfoResult, base_fname: str, ph: Phonopy
):
    print(
        _get_symmetry_yaml(phonon.primitive, phonon.primitive_symmetry, phonon.version)
    )
    print(
        f"# Input crystal structure: "
        f'"{cell_info.optional_structure_info.unitcell_filename}"'
    )
    if cell_info.phonopy_yaml is None:
        optional_structure_info = cell_info.optional_structure_info
        filename = "B" + base_fname
        print(f'# Symmetrized conventional unit cell is written into "{filename}" and')
        write_crystal_structure(
            filename,
            ph.unitcell,
            interface_mode=phonon.calculator,
            optional_structure_info=optional_structure_info,
        )
        filename = "P" + base_fname
        print(f'# Symmetrized primitive is written into "{filename}" and ')
        write_crystal_structure(
            filename,
            ph.primitive,
            interface_mode=phonon.calculator,
            optional_structure_info=optional_structure_info,
        )
    _write_symcells_yaml(ph)


def _write_symcells_yaml(ph: Phonopy):
    phyml = PhonopyYaml()
    phyml.primitive = ph.primitive
    phyml.unitcell = ph.unitcell
    with open("phonopy_symcells.yaml", "w") as w:
        print(phyml, file=w)

    print(
        '# Unit cell and primitive cell have been written in "phonopy_symcells.yaml".'
    )
    print("# These structures can be read in a python script as follows:")
    print("#")
    print("# import phonopy")
    print('# ph = phonopy.load("phonopy_symcells.yaml")')
    print("# unitcell = ph.unitcell")
    print("# primitive_cell = ph.primitive")


def _get_symmetry_yaml(cell: PhonopyAtoms, symmetry: Symmetry, phonopy_version=None):
    rotations = symmetry.symmetry_operations["rotations"]
    translations = symmetry.symmetry_operations["translations"]

    atom_sets = symmetry.get_map_atoms()
    independent_atoms = symmetry.get_independent_atoms()
    wyckoffs = symmetry.get_Wyckoff_letters()

    lines = []

    if phonopy_version is not None:
        lines.append("phonopy_version: '%s'" % phonopy_version)

    if cell.magnetic_moments is None:
        spg_symbol, spg_number = symmetry.get_international_table().split()
        spg_number = int(spg_number.replace("(", "").replace(")", ""))
        lines.append("space_group_type: '%s'" % spg_symbol)
        lines.append("space_group_number: %d" % spg_number)
        lines.append("point_group_type: '%s'" % symmetry.pointgroup_symbol)
    lines.append("space_group_operations:")
    for i, (r, t) in enumerate(zip(rotations, translations, strict=True)):
        lines.append("- rotation: # %d" % (i + 1))
        for vec in r:
            lines.append("  - [%2d, %2d ,%2d]" % tuple(vec))
        line = "  translation: ["
        for j, x in enumerate(t):
            if abs(x - np.rint(x)) < 1e-5:
                line += " 0.00000"
            else:
                line += "%8.5f" % x
            if j < 2:
                line += ", "
            else:
                line += " ]"
                lines.append(line)
    lines.append("atom_mapping:")
    for i, atom_num in enumerate(atom_sets):
        lines.append("  %d: %d" % (i + 1, atom_num + 1))
    lines.append("site_symmetries:")
    for i in independent_atoms:
        sitesym = symmetry.get_site_symmetry(i)
        lines.append("- atom: %d" % (i + 1))

        if cell.magnetic_moments is None:
            lines.append("  Wyckoff: '%s'" % wyckoffs[i])
        site_pointgroup = spglib.get_pointgroup(sitesym)
        lines.append("  site_point_group: '%s'" % site_pointgroup[0].strip())
        lines.append("  orientation:")
        for v in site_pointgroup[2]:
            lines.append("  - [%2d, %2d, %2d]" % tuple(v))

        lines.append("  rotations:")
        for j, r in enumerate(sitesym):
            lines.append("  - # %d" % (j + 1))
            for vec in r:
                lines.append("    - [%2d, %2d, %2d]" % tuple(vec))

    return "\n".join(lines)
