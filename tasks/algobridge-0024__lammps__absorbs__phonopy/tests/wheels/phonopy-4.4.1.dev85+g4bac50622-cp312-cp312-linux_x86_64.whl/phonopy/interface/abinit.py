# SPDX-License-Identifier: BSD-3-Clause
"""Abinit calculator interface."""

from __future__ import annotations

import io
import os
import sys
import typing
from collections.abc import Callable, Sequence
from typing import Any, Literal

import numpy as np
from numpy.typing import NDArray

from phonopy.cui.settings import fracval
from phonopy.file_IO import collect_forces
from phonopy.interface.vasp import (
    check_forces,
    get_drift_forces,
    get_scaled_positions_lines,
)
from phonopy.physical_units import get_physical_units
from phonopy.structure.atomic_data import get_atomic_data
from phonopy.structure.atoms import PhonopyAtoms


def parse_set_of_forces(
    num_atoms: int,
    forces_filenames: Sequence[str | os.PathLike],
    verbose: bool = True,
) -> list[NDArray[np.double]]:
    """Parse forces from output files."""
    hook = "cartesian forces (eV/Angstrom)"
    is_parsed = True
    force_sets = []
    for i, filename in enumerate(forces_filenames):
        if verbose:
            sys.stdout.write("%d. " % (i + 1))

        f = open(filename)
        abinit_forces = collect_forces(f, num_atoms, hook, [1, 2, 3])
        if check_forces(abinit_forces, num_atoms, filename, verbose=verbose):
            drift_force = get_drift_forces(
                abinit_forces, filename=filename, verbose=verbose
            )
            force_sets.append(np.array(abinit_forces) - drift_force)
        else:
            is_parsed = False

    if is_parsed:
        return force_sets
    else:
        return []


def read_abinit(filename: str | os.PathLike | typing.IO) -> PhonopyAtoms:
    """Read crystal structure."""
    if isinstance(filename, io.IOBase):
        abinit_in = AbinitIn(filename.readlines())  # type: ignore[arg-type]
    else:
        with open(filename) as f:  # type: ignore[arg-type]
            abinit_in = AbinitIn(f.readlines())
    tags = abinit_in.get_variables()
    acell = tags["acell"]
    rprim = tags["rprim"].T
    scalecart = tags["scalecart"]
    lattice = rprim * acell
    if scalecart is not None:
        for i in range(3):
            lattice[i] *= scalecart[i]

    if tags["xcart"] is not None:
        pos_bohr = np.transpose(tags["xcart"])
        positions = np.dot(np.linalg.inv(lattice), pos_bohr).T
    elif tags["xangst"] is not None:
        pos_bohr = np.transpose(tags["xangst"]) / get_physical_units().Bohr
        positions = np.dot(np.linalg.inv(lattice), pos_bohr).T
    elif tags["xred"] is not None:
        positions = tags["xred"]

    numbers = [tags["znucl"][x - 1] for x in tags["typat"]]
    atom_data = get_atomic_data().atom_data
    symbols = [atom_data[n][1] for n in numbers]

    return PhonopyAtoms(symbols=symbols, cell=lattice.T, scaled_positions=positions)


def write_abinit(filename: str | os.PathLike, cell: PhonopyAtoms) -> None:
    """Write cell to file."""
    with open(filename, "w") as f:
        f.write(get_abinit_structure(cell))


def write_supercells_with_displacements(
    supercell: PhonopyAtoms,
    cells_with_displacements: Sequence[PhonopyAtoms],
    ids: NDArray[np.int64] | Sequence[int],
    pre_filename: str | os.PathLike = "supercell",
    width: int = 3,
) -> None:
    """Write supercells with displacements to files."""
    write_abinit("%s.in" % pre_filename, supercell)
    for i, cell in zip(ids, cells_with_displacements, strict=True):
        filename = "{pre_filename}-{0:0{width}}.in".format(
            i, pre_filename=pre_filename, width=width
        )
        write_abinit(filename, cell)


def get_abinit_structure(cell: PhonopyAtoms) -> str:
    """Return abinit structure in text."""
    znucl = []
    numbers = cell.numbers
    for n in numbers:
        if n not in znucl:
            znucl.append(n)
    typat = []
    for n in numbers:
        typat.append(znucl.index(n) + 1)

    lines = ""
    lines += "natom %d\n" % len(numbers)
    lines += "typat\n"
    lines += (" %d" * len(typat) + "\n") % tuple(typat)
    lines += "ntypat %d\n" % len(znucl)
    lines += ("znucl" + " %d" * len(znucl) + "\n") % tuple(znucl)
    lines += "acell 1 1 1\n"
    lines += "rprim\n"
    lines += ((" % 20.16f" * 3 + "\n") * 3) % tuple(cell.cell.ravel())
    lines += "xred\n"
    lines += get_scaled_positions_lines(cell.scaled_positions)

    return lines


class AbinitIn:
    """Class to create Abinit input file."""

    def __init__(self, lines: list[str]) -> None:
        """Init method."""
        self._set_methods: dict[str, Callable[[], None]] = {
            "acell": self._set_acell,
            "natom": self._set_natom,
            "ntypat": self._set_ntypat,
            "rprim": self._set_rprim,
            "typat": self._set_typat,
            "scalecart": self._set_scalecart,
            "xangst": self._set_xangst,
            "xcart": self._set_xcart,
            "xred": self._set_xred,
            "znucl": self._set_znucl,
        }
        self._tags: dict[str, Any] = {
            "acell": None,
            "natom": None,
            "ntypat": None,
            "rprim": None,
            "typat": None,
            "scalecart": None,
            "xangst": None,
            "xcart": None,
            "xred": None,
            "znucl": None,
        }

        self._values: list[str] | None = None
        self._collect(lines)

    def get_variables(self) -> dict[str, Any]:
        """Return tags."""
        return self._tags

    def _collect(self, lines: list[str]) -> None:
        elements: dict[str, list[str]] = {}
        tag = None
        for line_tmp in lines:
            line = line_tmp.replace("!", "#").split("#")[0]
            for val in [x.lower() for x in line.split()]:
                if val in self._set_methods:
                    tag = val
                    elements[tag] = []
                elif tag is not None:
                    elements[tag].append(val)

        for tag in ["natom", "ntypat"]:
            if tag not in elements:
                print("%s is not found in the input file." % tag)
                sys.exit(1)

        for tag in elements:
            self._values = elements[tag]
            if tag == "natom" or tag == "ntypat":
                self._set_methods[tag]()

        for tag in elements:
            self._values = elements[tag]
            if tag != "natom" and tag != "ntypat":
                self._set_methods[tag]()

    def _get_numerical_values(
        self, char_string: str, num_type: Literal["float", "int"] = "float"
    ) -> list[float] | list[int]:
        m = 1

        if "*" in char_string:
            m = int(char_string.split("*")[0])
            str_val = char_string.split("*")[1]
        else:
            m = 1
            str_val = char_string

        if num_type == "float":
            a = fracval(str_val)
        else:
            a = int(str_val)

        return [a] * m

    def _set_acell(self) -> None:
        acell: list[float] = []
        for val in self._values:  # type: ignore[union-attr]
            if len(acell) >= 3:
                if len(val) >= 6:
                    if val[:6] == "angstr":
                        for i in range(3):
                            acell[i] /= get_physical_units().Bohr
                break

            acell += self._get_numerical_values(val)

        self._tags["acell"] = acell[:3]

    def _set_natom(self) -> None:
        self._tags["natom"] = int(self._values[0])  # type: ignore[index]

    def _set_ntypat(self) -> None:
        self._tags["ntypat"] = int(self._values[0])  # type: ignore[index]

    def _set_rprim(self) -> None:
        rprim: list[float] = []
        for val in self._values:  # type: ignore[union-attr]
            rprim += self._get_numerical_values(val)
            if len(rprim) >= 9:
                break

        self._tags["rprim"] = np.reshape(rprim[:9], (3, 3))

    def _set_scalecart(self) -> None:
        scalecart: list[float] = []
        for val in self._values:  # type: ignore[union-attr]
            scalecart += self._get_numerical_values(val)
            if len(scalecart) >= 3:
                break

        self._tags["scalecart"] = np.array(scalecart[:3])

    def _set_typat(self) -> None:
        typat: list[int] = []
        natom = self._tags["natom"]
        for val in self._values:  # type: ignore[union-attr]
            typat += self._get_numerical_values(val, num_type="int")  # type: ignore[arg-type]
            if len(typat) >= natom:
                break

        self._tags["typat"] = typat[:natom]

    def _set_xangst(self) -> None:
        self._set_x_tags("xangst")

    def _set_xcart(self) -> None:
        self._set_x_tags("xcart")

    def _set_xred(self) -> None:
        self._set_x_tags("xred")

    def _set_x_tags(self, tagname: str) -> None:
        xtag: list[float] = []
        natom = self._tags["natom"]
        for val in self._values:  # type: ignore[union-attr]
            xtag += self._get_numerical_values(val)
            if len(xtag) >= natom * 3:
                break

        self._tags[tagname] = np.reshape(xtag[: natom * 3], (-1, 3))

    def _set_znucl(self) -> None:
        znucl: list[int] = []
        ntypat = self._tags["ntypat"]
        for val in self._values:  # type: ignore[union-attr]
            znucl += self._get_numerical_values(val, num_type="int")  # type: ignore[arg-type]
            if len(znucl) >= ntypat:
                break

        self._tags["znucl"] = znucl[:ntypat]
