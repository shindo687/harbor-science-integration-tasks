# SPDX-License-Identifier: BSD-3-Clause
"""Force constants calculation."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Literal

import numpy as np
from numpy.typing import NDArray

from phonopy._lang import log_dispatch, resolve_lang
from phonopy.harmonic.displacement import Type1DisplacementDataset
from phonopy.structure.atoms import PhonopyAtoms
from phonopy.structure.cells import (
    Primitive,
    compute_permutation_for_rotation,
    get_atom_order,
    get_smallest_vectors,
)
from phonopy.structure.symmetry import Symmetry
from phonopy.utils import similarity_transformation


class FDFCSolver:
    """Finite difference type force constants calculator.

    This is phonopy's traditional force constants calculator.

    """

    def __init__(
        self,
        supercell: PhonopyAtoms,
        primitive: Primitive | None,
        symmetry: Symmetry,
        dataset: Type1DisplacementDataset,
        is_compact_fc: bool = False,
        log_level: int = 0,  # currently not used
        lang: Literal["C", "Rust"] = "Rust",
    ):
        if is_compact_fc and primitive:
            atom_list = primitive.p2s_map
        else:
            atom_list = np.arange(len(supercell), dtype="int64")

        self._fc2 = self._run(
            supercell,
            symmetry,
            dataset,
            atom_list=atom_list,
            primitive=primitive,
            lang=lang,
        )

    @property
    def force_constants(self) -> dict[int, np.ndarray]:
        """Return force constants.

        Returns
        -------
        dict[int, np.ndarray]
            Force constants with order as key.

        """
        return {2: self._fc2}

    def _run(
        self,
        supercell: PhonopyAtoms,
        symmetry: Symmetry,
        dataset: Type1DisplacementDataset,
        atom_list: NDArray[np.int64] | None = None,
        primitive: Primitive | None = None,
        lang: Literal["C", "Rust"] = "Rust",
    ) -> NDArray[np.double]:
        """Force constants are computed.

        Force constants, Phi, are calculated from sets for forces, F, and
        atomic displacement, d:
        Phi = -F / d
        This is solved by matrix pseudo-inversion.
        Crystal symmetry is included when creating F and d matrices.

        Returns
        -------
        ndarray
            Force constants[ i, j, a, b ]
            i: Atom index of finitely displaced atom.
            j: Atom index at which force on the atom is measured.
            a, b: Cartesian direction indices = (0, 1, 2) for i and j, respectively
            dtype=double
            shape=(len(atom_list),n_satom,3,3),

        """
        if atom_list is None:
            fc_dim0 = len(supercell)
        else:
            fc_dim0 = len(atom_list)

        force_constants = np.zeros(
            (fc_dim0, len(supercell), 3, 3), dtype="double", order="C"
        )

        # Fill force_constants[ displaced_atoms, all_atoms_in_supercell ]
        atom_list_done = _get_force_constants_disps(
            force_constants,
            supercell,
            dataset,
            symmetry,
            atom_list=atom_list,
            lang=lang,
        )
        rotations = symmetry.symmetry_operations["rotations"]
        lattice = np.array(supercell.cell.T, dtype="double", order="C")
        permutations = symmetry.atomic_permutations

        if atom_list is None and primitive is not None:
            # Distribute to atoms in primitive cell, then distribute to all.
            distribute_force_constants(
                force_constants,
                atom_list_done,
                lattice,
                rotations,
                permutations,
                atom_list=primitive.p2s_map,
                fc_indices_of_atom_list=primitive.p2s_map,
                lang=lang,
            )
            distribute_force_constants_by_translations(
                force_constants, primitive, lang=lang
            )
        else:
            distribute_force_constants(
                force_constants,
                atom_list_done,
                lattice,
                rotations,
                permutations,
                atom_list=atom_list,
                lang=lang,
            )

        return force_constants


def compact_fc_to_full_fc(
    primitive: Primitive,
    compact_fc: NDArray[np.double],
    log_level: int = 0,
    lang: Literal["C", "Rust"] | None = None,
) -> NDArray[np.double]:
    """Transform compact fc to full fc.

    ``lang`` defaults to ``primitive._lang`` (the backend already selected
    on the input primitive), so callers don't have to thread it through.

    """
    fc = np.zeros(
        (compact_fc.shape[1], compact_fc.shape[1], 3, 3), dtype="double", order="C"
    )
    fc[primitive.p2s_map] = compact_fc
    distribute_force_constants_by_translations(
        fc, primitive, lang=lang if lang is not None else primitive._lang
    )
    if log_level:
        print("Force constants were expanded to full format.")

    return fc


def full_fc_to_compact_fc(
    primitive: Primitive, full_fc: NDArray[np.double], log_level: int = 0
) -> NDArray[np.double]:
    """Transform full fc to compact fc."""
    p2s_map = primitive.p2s_map
    fc = np.zeros((len(p2s_map), full_fc.shape[1], 3, 3), dtype="double", order="C")
    fc[:] = full_fc[p2s_map]
    if log_level:
        print("Force constants format was transformed to compact format.")

    return fc


def rearrange_force_constants_array(
    full_fc: NDArray[np.double], a: PhonopyAtoms, b: PhonopyAtoms
) -> tuple[NDArray[np.double], list[int]]:
    """Rearrange force constants array of cell-a to those of cell-b.

    Parameters
    ----------
    full_fc : ndarray
        Force constants in full array format.
    a : PhonopyAtoms
        Cell of input force constants.
    b : PhonopyAtoms
        Cell of rearranged force constants.

    Returns
    -------
    ndarray
        Rearranged force constants array.

    """
    assert full_fc.shape[0] == full_fc.shape[1]
    indices = get_atom_order(a, b)
    assert indices is not None
    re_fc = np.zeros_like(full_fc)
    for i, j in enumerate(indices):
        re_fc[i] = full_fc[j][indices]
    return re_fc, indices


def cutoff_force_constants(
    force_constants: NDArray[np.double],
    supercell: PhonopyAtoms,
    primitive: Primitive,
    cutoff_radius: float,
    symprec: float = 1e-5,
) -> None:
    """Set zero to force constants outside of cutoff distance.

    Note
    ----
    `force_constants` is overwritten.

    """
    fc_shape = force_constants.shape

    if fc_shape[0] == fc_shape[1]:
        svecs, multi = get_smallest_vectors(
            supercell.cell,
            supercell.scaled_positions,
            supercell.scaled_positions,
            symprec=symprec,
            store_dense_svecs=primitive.store_dense_svecs,
        )
        lattice = supercell.cell
    else:
        svecs, multi = primitive.get_smallest_vectors()
        lattice = primitive.cell

    if primitive.store_dense_svecs:
        _svecs = svecs[multi[:, :, 1]]
    else:
        _svecs = svecs[:, :, 0, :]

    min_distances = np.sqrt(np.sum(np.dot(_svecs, lattice) ** 2, axis=-1))

    for i in range(fc_shape[0]):
        for j in range(fc_shape[1]):
            if min_distances[j, i] > cutoff_radius:
                force_constants[i, j] = 0.0


def symmetrize_force_constants(
    force_constants: NDArray[np.double],
    level: int = 1,
    lang: Literal["C", "Rust"] = "Rust",
) -> None:
    """Symmetry force constants by translational and permutation symmetries.

    Note
    ----
    Schemes of symmetrization are slightly different between C and
    python implementations. If these give very different results, the
    original force constants are not reliable anyway.

    Parameters
    ----------
    force_constants: ndarray
        Force constants. Symmetrized force constants are overwritten.
        dtype=double
        shape=(n_satom,n_satom,3,3)
    primitive: Primitive
        Primitive cell
    level: int
        Controls the number of times the following steps repeated:
        1) Subtract drift force constants along row and column
        2) Average fc and fc.T
    lang : {"C", "Rust"}
        Backend for the symmetrization kernel. Default is "C".  Rust
        falls back to the C path automatically if the phonors extension
        is not importable.

    """
    try:
        if lang == "Rust":
            import phonors  # type: ignore

            log_dispatch(lang, "symmetrize_force_constants")
            phonors.perm_trans_symmetrize_fc(force_constants, level)
            return

        import phonopy._phonopy as phonoc  # type: ignore

        log_dispatch(lang, "symmetrize_force_constants")
        phonoc.perm_trans_symmetrize_fc(force_constants, level)
    except ImportError:
        for _ in range(level):
            set_translational_invariance(force_constants)
            set_permutation_symmetry(force_constants)
        set_translational_invariance(force_constants)


def symmetrize_compact_force_constants(
    force_constants: NDArray[np.double],
    primitive: Primitive,
    level: int = 1,
    lang: Literal["C", "Rust"] = "Rust",
) -> None:
    """Symmetry force constants by translational and permutation symmetries.

    Parameters
    ----------
    force_constants: ndarray
        Compact force constants. Symmetrized force constants are overwritten.
        dtype=double
        shape=(n_patom,n_satom,3,3)
    primitive: Primitive
        Primitive cell
    level: int
        Controls the number of times the following steps repeated:
        1) Subtract drift force constants along row and column
        2) Average fc and fc.T
    lang : {"C", "Rust"}
        Backend for the symmetrization kernel. Default is "C".

    """
    s2p_map = primitive.s2p_map
    p2s_map = primitive.p2s_map
    p2p_map = primitive.p2p_map
    permutations = primitive.atomic_permutations
    s2pp_map, nsym_list = get_nsym_list_and_s2pp(s2p_map, p2p_map, permutations)
    try:
        if lang == "Rust":
            import phonors  # type: ignore

            log_dispatch(lang, "symmetrize_compact_force_constants")
            phonors.perm_trans_symmetrize_compact_fc(
                force_constants,
                permutations,
                s2pp_map,
                p2s_map,
                nsym_list,
                level,
            )
            return

        import phonopy._phonopy as phonoc  # type: ignore

        log_dispatch(lang, "symmetrize_compact_force_constants")
        phonoc.perm_trans_symmetrize_compact_fc(
            force_constants,
            permutations,
            s2pp_map,
            p2s_map,
            nsym_list,
            level,
        )
    except ImportError as exc:
        text = (
            "Import error at perm_trans_symmetrize_compact_fc. "
            "Corresponding pytono code is not implemented."
        )
        raise RuntimeError(text) from exc


def distribute_force_constants(
    force_constants: NDArray[np.double],
    atom_list_done: NDArray[np.int64],
    lattice: NDArray[np.double],  # column vectors
    rotations: NDArray[np.int64],  # scaled (fractional)
    permutations: NDArray[np.int64],
    atom_list: Sequence[int] | NDArray[np.int64] | None = None,
    fc_indices_of_atom_list: Sequence[int] | NDArray[np.int64] | None = None,
    lang: Literal["C", "Rust"] = "Rust",
) -> None:
    """Fill force constants elements by symmetry.

    atom_list : ndarray
        Indices of target atoms.
    permutations : ndarray
        Atomic index permutation table by symmetry operations.
        shape=(num_rot, num_pos), dtype='int64', order='C'
    fc_indices_of_atom_list : ndarray
        First fc3 indices corresponding to indices of target atoms. Unless
        specified, `range(len(atom_list))` is used.
    lang : {"C", "Rust"}
        Backend for the distribution kernel. Default is "C".

    """
    map_atoms, map_syms = _get_sym_mappings_from_permutations(
        permutations, atom_list_done
    )
    rots_cartesian = np.array(
        [similarity_transformation(lattice, r) for r in rotations],
        dtype="double",
        order="C",
    )
    if atom_list is None:
        targets = np.arange(force_constants.shape[1], dtype="int64")
    else:
        targets = np.array(atom_list, dtype="int64")
    if fc_indices_of_atom_list is None:
        _fc_indices_of_atom_list = np.arange(len(targets), dtype="int64")
    else:
        _fc_indices_of_atom_list = np.array(fc_indices_of_atom_list, dtype="int64")

    if map_atoms.ndim != 1 or map_atoms.shape[0] != permutations.shape[1]:
        raise ValueError("wrong shape for map_atoms")

    if map_syms.ndim != 1 or map_syms.shape[0] != permutations.shape[1]:
        raise ValueError("wrong shape for map_syms")

    if rots_cartesian.shape[0] != permutations.shape[0]:
        raise ValueError("permutations and rotations are different length")

    if lang == "Rust":
        import phonors  # type: ignore

        log_dispatch(lang, "distribute_force_constants")
        phonors.distribute_fc2(
            force_constants,
            targets,
            _fc_indices_of_atom_list,
            rots_cartesian,
            permutations,
            map_atoms,
            map_syms,
        )
    else:
        import phonopy._phonopy as phonoc  # type: ignore

        log_dispatch(lang, "distribute_force_constants")
        phonoc.distribute_fc2(
            force_constants,
            targets,
            _fc_indices_of_atom_list,
            rots_cartesian,
            permutations,
            map_atoms,
            map_syms,
        )


def distribute_force_constants_by_translations(
    fc: NDArray[np.double],
    primitive: Primitive,
    lang: Literal["C", "Rust"] = "Rust",
) -> None:
    """Distribute compact fc data to full fc by pure translations.

    For example, the input fc has to be prepared in the following way
    in advance:

    fc = np.zeros((compact_fc.shape[1], compact_fc.shape[1], 3, 3),
                  dtype='double', order='C')
    fc[primitive.p2s_map] = compact_fc

    """
    p2s = primitive.p2s_map
    permutations = primitive.atomic_permutations
    lattice = primitive.cell.T @ np.linalg.inv(primitive.primitive_matrix)
    rotations = np.array(
        [np.eye(3, dtype="int64")] * permutations.shape[0],
        dtype="int64",
        order="C",
    )
    distribute_force_constants(fc, p2s, lattice, rotations, permutations, lang=lang)


def solve_force_constants(
    force_constants: NDArray[np.double],
    disp_atom_number: int,
    displacements: Sequence[NDArray[np.double]] | Sequence[Sequence[float]],
    sets_of_forces: Sequence[NDArray[np.double]] | NDArray[np.double],
    supercell: PhonopyAtoms,
    site_symmetry: NDArray[np.int64],
    symprec: float,
    atom_list: NDArray[np.int64] | None = None,
    lang: Literal["C", "Rust"] = "Rust",
) -> None:
    """Calculate force constants elements of pairs from an atom."""
    if atom_list is None:
        fc_index = disp_atom_number
    else:
        fc_index = np.where(disp_atom_number == atom_list)[0]
        if len(fc_index) == 0:
            raise RuntimeError(
                "Force constants could not be sovlved by finite difference method."
            )
        else:
            fc_index = fc_index[0]
    force_constants[fc_index] = _solve_force_constants_svd(
        disp_atom_number,
        displacements,
        sets_of_forces,
        supercell,
        site_symmetry,
        symprec,
        lang=lang,
    )
    return None


def get_positions_sent_by_rot_inv(
    lattice: NDArray[np.double],
    positions: NDArray[np.double],
    site_symmetry: NDArray[np.int64],
    symprec: float,
    types: NDArray[np.int64] | Sequence[int] | None,
    lang: Literal["C", "Rust"] = "Rust",
) -> NDArray[np.int64]:
    """Return atom indices of positions sent by inverse site symmetries.

    Rotated_positions[rot_map] == positions.

    Parameters
    ----------
    lattice : ndarray
        Basis vectors in column vectors (like PhonopyAtoms.cell.T)
    positions : ndarray
        Scaled positions shifted by a displaced atom as the origin.
    site_symmetry : ndarray
        Site symmetry operations of the displaced atom.
    symprec : float
        Tolerance of symmetry.
    types : array_like or None
        Per-atom integer types (required). When given, atoms are matched
        only within the same type so co-located atoms of different species
        (e.g. in a site-mixture cell) are not paired. Pass None to match by
        position alone. See ``compute_permutation_for_rotation``.

    Note
    ----
    This method is public because of being used by phono3py.

    """
    rot_map_syms = []
    for sym in site_symmetry:
        rot_map = compute_permutation_for_rotation(
            np.dot(positions, sym.T),
            positions,
            lattice,
            symprec,
            types,
            lang=lang,
        )
        rot_map_syms.append(rot_map)

    return np.array(rot_map_syms, dtype="int64", order="C")


def get_rotated_displacement(
    displacements: Sequence[NDArray[np.double]] | Sequence[Sequence[float]],
    site_sym_cart: Sequence[NDArray[np.double]],
) -> NDArray[np.double]:
    """Rotate displacements by site symmetry.

    Note
    ----
    This method is public because of being used by phono3py.

    """
    rot_disps = []
    for u in displacements:
        rot_disps.append([np.dot(sym, u) for sym in site_sym_cart])
    return np.array(np.reshape(rot_disps, (-1, 3)), dtype="double", order="C")


def set_tensor_symmetry_PJ(
    force_constants: NDArray[np.double],
    lattice: NDArray[np.double],
    positions: NDArray[np.double],
    symmetry: Symmetry,
) -> None:
    """Full force constants are symmetrized using crystal symmetry.

    This method extracts symmetrically equivalent sets of atomic pairs and
    take sum of their force constants and average the sum.

    Parameters
    ----------
    force_constants : ndarray
        Force constants.
        shape=(n_satom, n_satom, 3, 3), dtype='double', order='C'
    lattice : ndarray
        Basis vectors in column vectors.
        shape=(3, 3), dtype='double'
    positions : ndarray
        Atomic positions in scaled coordinates.
        shape=(n_satom, 3), dtype='double', order='C'
    symmetry : Symmetry
        Symmetry of the supercell.

    """
    rotations = symmetry.symmetry_operations["rotations"]
    translations = symmetry.symmetry_operations["translations"]
    symprec = symmetry.tolerance

    N = len(rotations)

    mapa = _get_atom_indices_by_symmetry(
        lattice, positions, rotations, translations, symprec
    )
    cart_rot = np.array(
        [similarity_transformation(lattice, rot).T for rot in rotations]
    )
    cart_rot_inv = np.array([np.linalg.inv(rot) for rot in cart_rot])
    fcm = np.array(
        [force_constants[mapa[n], :, :, :][:, mapa[n], :, :] for n in range(N)]
    )
    s = np.transpose(
        np.array(
            [np.dot(cart_rot[n], np.dot(fcm[n], cart_rot_inv[n])) for n in range(N)]
        ),
        (0, 2, 3, 1, 4),
    )
    force_constants[:] = np.array(np.average(s, axis=0), dtype="double", order="C")


def set_translational_invariance(force_constants: NDArray[np.double]) -> None:
    """Impose translational invariance (Python version).

    The type1 is quite simple implementation, which is just taking sum of the
    force constants in an axis and an atom index. The sum has to be zero due to
    the translational invariance. If the sum is not zero, this error is
    uniformly subtracted from force constants.

    """
    for i in range(2):
        set_translational_invariance_per_index(force_constants, index=i)


def set_translational_invariance_per_index(
    fc2: NDArray[np.double], index: int = 0
) -> None:
    """Impose translational invariance per index (Python version)."""
    for i in range(fc2.shape[1 - index]):
        for j, k in list(np.ndindex(3, 3)):
            if index == 0:
                fc2[:, i, j, k] -= np.sum(fc2[:, i, j, k]) / fc2.shape[0]
            else:
                fc2[i, :, j, k] -= np.sum(fc2[i, :, j, k]) / fc2.shape[1]


def set_permutation_symmetry(force_constants: NDArray[np.double]) -> None:
    """Enforce permutation symmetry to force constants (Python version).

    This is done by

        Phi_ij_ab = Phi_ji_ba

    i, j: atom index
    a, b: Cartesian axis index

    This is not necessary for harmonic phonon calculation because this
    condition is imposed when making dynamical matrix Hermite in
    dynamical_matrix.py.

    """
    fc_copy = force_constants.copy()
    for i in range(force_constants.shape[0]):
        for j in range(force_constants.shape[1]):
            force_constants[i, j] = (force_constants[i, j] + fc_copy[j, i].T) / 2


def get_drift_force_constants(
    force_constants: NDArray[np.double],
    primitive: Primitive | None = None,
    lang: Literal["C", "Rust"] = "Rust",
) -> tuple[float, float, list[int], list[int]]:
    """Get max drift of force constants."""
    lang = resolve_lang(lang)
    if force_constants.shape[0] == force_constants.shape[1]:
        num_atom = force_constants.shape[0]
        maxval1 = 0
        maxval2 = 0
        xy1 = [0, 0]
        xy2 = [0, 0]
        for i, j, k in list(np.ndindex((num_atom, 3, 3))):
            val1 = force_constants[:, i, j, k].sum()
            val2 = force_constants[i, :, j, k].sum()
            if abs(val1) > abs(maxval1):
                maxval1 = val1
                xy1 = [j, k]
            if abs(val2) > abs(maxval2):
                maxval2 = val2
                xy2 = [j, k]
    else:
        if primitive is None:
            raise RuntimeError(
                "Primitive cell is necessary to get drift force constants."
            )
        s2p_map = primitive.s2p_map
        p2s_map = primitive.p2s_map
        p2p_map = primitive.p2p_map
        permutations = primitive.atomic_permutations
        s2pp_map, nsym_list = get_nsym_list_and_s2pp(s2p_map, p2p_map, permutations)

        try:
            if lang == "Rust":
                import phonors  # type: ignore

                log_dispatch(lang, "get_drift_force_constants")
                transpose = phonors.transpose_compact_fc
            else:
                import phonopy._phonopy as phonoc  # type: ignore

                log_dispatch(lang, "get_drift_force_constants")
                transpose = phonoc.transpose_compact_fc

            transpose(
                force_constants,
                permutations,
                s2pp_map,
                p2s_map,
                nsym_list,
            )
            maxval1, xy1 = _get_drift_per_index(force_constants)
            transpose(
                force_constants,
                permutations,
                s2pp_map,
                p2s_map,
                nsym_list,
            )
            maxval2, xy2 = _get_drift_per_index(force_constants)

        except ImportError as exc:
            text = (
                "Import error at transpose_compact_fc. "
                "Corresponding python code is not implemented."
            )
            raise RuntimeError(text) from exc

    return maxval1, maxval2, xy1, xy2


def show_drift_force_constants(
    force_constants: NDArray[np.double],
    primitive: Primitive | None = None,
    name: str = "force constants",
    values_only: bool = False,
    digit: int = 8,
    lang: Literal["C", "Rust"] = "Rust",
):
    """Show force constants drift."""
    maxval1, maxval2, xy1, xy2 = get_drift_force_constants(
        force_constants, primitive=primitive, lang=lang
    )

    if values_only:
        text = ""
    else:
        text = "Max drift of %s: " % name
    text += f"{maxval1:.{digit}f} ({'xyz'[xy1[0]]}{'xyz'[xy1[1]]}) "
    text += f"{maxval2:.{digit}f} ({'xyz'[xy2[0]]}{'xyz'[xy2[1]]}) "
    print(text)


def get_nsym_list_and_s2pp(
    s2p_map: NDArray[np.int64],
    p2p_map: dict[int, int],
    permutations: NDArray[np.int64],
) -> tuple[NDArray[np.int64], NDArray[np.int64]]:
    """Find lattice points corresponding to atoms in s2p_map.

    Parameters
    ----------
    s2p_map : array_like
        See Primitive class.
    p2p_map : dict
        See Primitive class.
    permutations : ndarray
        See Primitive.atomic_permutations.

    Returns
    -------
    s2pp : ndarray
        Atom indices in primitive cell that correspond to supercell atoms.
        shape=(num_atoms_in_supercell, ), dtype='int64'
    nsym_list : ndarray
        Pure translation indices that map atoms in supercell to those in
        primitive cell.
        shape=(num_pure_translation, ), dtype='int64'

    Note
    ----
    This method is public because of being used by phono3py.

    """
    s2pp = np.array([p2p_map[i] for i in s2p_map], dtype="int64")
    nsym_list = np.array(
        [
            np.where(permutations[:, i] == target)[0][0]
            for i, target in enumerate(s2p_map)
        ],
        dtype="int64",
    )
    return s2pp, nsym_list


def get_harmonic_potential_energy(
    force_constants: NDArray[np.double],
    displacements: NDArray[np.double],
) -> float | list[float]:
    """Calculate harmonic potential energy of displacements.

    Parameters
    ----------
    force_constants : ndarray
        Full shape force constants.
        shape=(num_supercell_atoms, num_supercell_atoms, 3, 3), dtype='double'
    displacements : ndarray
        Displacements of atoms.
        shape=(num_supercell_atoms, 3) or shape=(N, num_supercell_atoms, 3),
        dtype='double'
        N in shape means number of snapshots.

    Returns
    -------
    float or list of float
        Increase of harmonic potential energy by displacements.

    Note
    ----
    This is not directly used in phonopy, but is kept useful.

    """
    if force_constants.shape[0] != force_constants.shape[1]:
        raise RuntimeError("Full shape force constants are necessary.")

    def _get_harm_pot(fc, d):
        return np.dot(d, np.dot(fc, d)) / 2

    n = force_constants.shape[0]
    fc = np.swapaxes(force_constants, 1, 2).reshape(n * 3, n * 3)
    if displacements.ndim == 3:
        return [_get_harm_pot(fc, d.ravel()) for d in displacements]
    elif displacements.ndim == 2:
        d = displacements.ravel()
        return _get_harm_pot(fc, d)
    else:
        raise RuntimeError("Array shape of displacements is wrong.")


def _get_rotated_forces(
    forces_syms: NDArray[np.double],
    site_sym_cart: list[NDArray[np.double]],
) -> list[NDArray[np.double]]:
    rot_forces = []
    for forces, sym_cart in zip(forces_syms, site_sym_cart, strict=True):
        rot_forces.append(np.dot(forces, sym_cart.T))

    return rot_forces


def _get_drift_per_index(
    force_constants: NDArray[np.double],
) -> tuple[float, list[int]]:
    num_atom = force_constants.shape[0]
    maxval = 0
    jk = [0, 0]
    for i, j, k in list(np.ndindex((num_atom, 3, 3))):
        val = force_constants[i, :, j, k].sum()
        if abs(val) > abs(maxval):
            maxval = val
            jk = [j, k]
    return maxval, jk


def _solve_force_constants_svd(
    disp_atom_number: int,
    displacements: Sequence[NDArray[np.double]] | Sequence[Sequence[float]],
    sets_of_forces: Sequence[NDArray[np.double]] | NDArray[np.double],
    supercell: PhonopyAtoms,
    site_symmetry: NDArray[np.int64],
    symprec: float,
    lang: Literal["C", "Rust"] = "Rust",
) -> NDArray[np.double]:
    lattice = supercell.cell.T
    positions = supercell.scaled_positions
    pos_center = positions[disp_atom_number]
    positions -= pos_center
    rot_map_syms = get_positions_sent_by_rot_inv(
        lattice,
        positions,
        site_symmetry,
        symprec,
        supercell.permutation_types,
        lang=lang,
    )
    site_sym_cart = [similarity_transformation(lattice, sym) for sym in site_symmetry]
    rot_disps = get_rotated_displacement(displacements, site_sym_cart)
    inv_displacements = np.linalg.pinv(rot_disps)

    fc = np.zeros((len(supercell), 3, 3), dtype="double", order="C")
    for i in range(len(supercell)):
        combined_forces = []
        for forces in sets_of_forces:
            combined_forces.append(
                _get_rotated_forces(forces[rot_map_syms[:, i]], site_sym_cart)
            )

        combined_forces = np.reshape(combined_forces, (-1, 3))
        fc[i] = -np.dot(inv_displacements, combined_forces)
    return fc


def _get_force_constants_disps(
    force_constants: NDArray[np.double],
    supercell: PhonopyAtoms,
    dataset: Type1DisplacementDataset,
    symmetry: Symmetry,
    atom_list: NDArray[np.int64] | None = None,
    lang: Literal["C", "Rust"] = "Rust",
) -> NDArray[np.int64]:
    """Calculate force constants Phi = -F / d.

    Force constants are obtained by one of the following algorithm.

    Parameters
    ----------
    force_constants: ndarray
        Force constants
        shape=(len(atom_list),n_satom,3,3)
        dtype=double
    supercell: PhonopyAtoms
        Supercell
    dataset: dict
        Type-1 distplacement dataset. Forces are also stored.
    symmetry: Symmetry
        Symmetry information of supercell
    atom_list: ndarray or None
        List of atom indices corresponding to the first index of force
        constants. None assigns all atoms in supercell.

    """
    symprec = symmetry.tolerance
    disp_atom_list = np.unique([x["number"] for x in dataset["first_atoms"]])
    for disp_atom_number in disp_atom_list:
        disps = []
        sets_of_forces = []

        for data_1st in dataset["first_atoms"]:
            if data_1st["number"] != disp_atom_number:
                continue
            disps.append(data_1st["displacement"])
            assert "forces" in data_1st
            sets_of_forces.append(data_1st["forces"])

        site_symmetry = symmetry.get_site_symmetry(disp_atom_number)

        solve_force_constants(
            force_constants,
            disp_atom_number,
            disps,
            sets_of_forces,
            supercell,
            site_symmetry,
            symprec,
            atom_list=atom_list,
            lang=lang,
        )

    return disp_atom_list


def _get_atom_indices_by_symmetry(
    lattice: NDArray[np.double],
    positions: NDArray[np.double],
    rotations: NDArray[np.int64],
    translations: NDArray[np.double],
    symprec: float,
) -> NDArray[np.int64]:
    # To understand this method, understanding numpy broadcasting is mandatory.

    K = len(positions)
    # positions[K, 3]
    # dot()[K, N, 3] where N is number of sym opts.
    # translation[N, 3] is added to the last two dimensions after dot().
    rpos = np.dot(positions, np.transpose(rotations, (0, 2, 1))) + translations

    # np.tile(rpos, (K, 1, 1, 1))[K(2), K(1), N, 3]
    # by adding one dimension in front of [K(1), N, 3].
    # np.transpose(np.tile(rpos, (K, 1, 1, 1)), (2, 1, 0, 3))[N, K(1), K(2), 3]
    diff = positions - np.transpose(np.tile(rpos, (K, 1, 1, 1)), (2, 1, 0, 3))
    diff -= np.rint(diff)
    diff = np.dot(diff, lattice.T)
    # m[N, K(1), K(2)]
    m = np.sqrt(np.sum(diff**2, axis=3)) < symprec
    # index_array[K(1), K(2)]
    index_array = np.tile(np.arange(K, dtype="int64"), (K, 1))
    # Understanding numpy boolean array indexing (extract True elements)
    # mapa[N, K(1)]
    mapa = np.array([index_array[mr] for mr in m], dtype="int64")
    return mapa


def _get_sym_mappings_from_permutations(
    permutations: NDArray[np.int64],
    atom_list_done: NDArray[np.int64] | Sequence[int],
) -> tuple[NDArray[np.int64], NDArray[np.int64]]:
    """Find atomic indices where force constants have not yet calculated.

    This can be thought of as computing 'map_atom_disp' and 'map_sym'
    for all atoms, except done using permutations instead of by
    computing overlaps.

    Parameters
    ----------
    permutations : ndarray
        Atomic index permutation table by space group operations.
        shape=(operations, positions)
    atom_list_done : array_like
         Atomic indices where force constants (first index) were already
         calculated.

    Returns
    -------
    map_atoms : ndarray
        Maps each atom in the full structure to its equivalent atom in
        atom_list_done.  (each entry will be an integer found in
        atom_list_done)
        shape=(positions, ), dtype='int64'
    map_syms : ndarray
        For each atom, provides the index of a rotation that maps it
        into atom_list_done.  (there might be more than one such
        rotation, but only one will be returned) (each entry will be
        an integer 0 <= i < num_rot)
        shape=(positions, ), dtype='int64'

    """
    assert permutations.ndim == 2
    num_pos = permutations.shape[1]

    # filled with -1
    map_atoms = np.zeros((num_pos,), dtype="int64") - 1
    map_syms = np.zeros((num_pos,), dtype="int64") - 1

    atom_list_done_set = set(atom_list_done)
    for atom_todo in range(num_pos):
        for sym_index, permutation in enumerate(permutations):
            if permutation[atom_todo] in atom_list_done_set:
                map_atoms[atom_todo] = permutation[atom_todo]
                map_syms[atom_todo] = sym_index
                break
        else:
            text = (
                "Input forces are not enough to calculate force constants,"
                "or something wrong (e.g. crystal structure does not "
                "match)."
            )
            raise ValueError(text)

    assert set(map_atoms) & atom_list_done_set == set(map_atoms)
    assert -1 not in map_atoms
    assert -1 not in map_syms
    return map_atoms, map_syms
