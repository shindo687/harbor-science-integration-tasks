# SPDX-License-Identifier: BSD-3-Clause
"""Mode Grueneisen parameter band structure calculation."""

from __future__ import annotations

import gzip
import lzma
import os
from collections.abc import Sequence
from typing import IO, Any, Literal

import numpy as np
import yaml  # type: ignore[import-untyped]
from numpy.typing import NDArray

from phonopy.gruneisen.core import GruneisenBase
from phonopy.harmonic.dynamical_matrix import DynamicalMatrix
from phonopy.physical_units import get_physical_units

BandPath = tuple[
    NDArray[np.double],
    NDArray[np.double],
    NDArray[np.double],
    NDArray[np.double],
    NDArray[np.cdouble],
    NDArray[np.double],
    NDArray[np.double],
]


class GruneisenBandStructure(GruneisenBase):
    """Class to calculate mode Grueneisen parameter along band structure paths."""

    def __init__(
        self,
        paths: Sequence[Sequence[Sequence[float]]] | Sequence[NDArray[np.double]],
        dynmat: DynamicalMatrix,
        dynmat_plus: DynamicalMatrix,
        dynmat_minus: DynamicalMatrix,
        delta_strain: float | None = None,
        path_connections: list[bool] | None = None,
        labels: Sequence[str] | None = None,
        factor: float | None = None,
    ) -> None:
        """Init method."""
        super().__init__(
            dynmat,
            dynmat_plus,
            dynmat_minus,
            delta_strain=delta_strain,
            is_band_connection=True,
        )
        self._cell = dynmat.primitive
        rec_lattice = np.linalg.inv(self._cell.cell)
        distance_shift = 0.0

        if factor is None:
            _factor = get_physical_units().DefaultToTHz
        else:
            _factor = factor

        self._paths: list[BandPath] = []
        self._is_legacy_plot = False
        for _qpoints in paths:
            qpoints = np.array(_qpoints, dtype="double")
            distances = np.zeros(len(qpoints))
            delta_qpoints = qpoints[1:] - qpoints[:-1]
            delta_distances = np.sqrt(
                (np.dot(delta_qpoints, rec_lattice) ** 2).sum(axis=1)
            )
            for i, dd in enumerate(delta_distances):
                distances[i + 1] = distances[i] + dd

            self.set_qpoints(qpoints)
            eigenvalues = self._eigenvalues
            assert eigenvalues is not None
            assert self._gruneisen is not None
            assert self._eigenvectors is not None
            frequencies = np.sqrt(abs(eigenvalues)) * np.sign(eigenvalues) * _factor
            distances_with_shift = distances + distance_shift

            self._paths.append(
                (
                    qpoints,
                    distances,
                    self._gruneisen,
                    eigenvalues,
                    self._eigenvectors,
                    frequencies,
                    distances_with_shift,
                )
            )

            distance_shift = distances_with_shift[-1]
        self._labels: Sequence[str] | None = None
        self._path_connections: list[bool] | None = None
        if path_connections is None:
            self._path_connections = [
                True,
            ] * len(self._paths)
            self._path_connections[-1] = False
        else:
            self._path_connections = path_connections
        if (
            labels is not None
            and len(labels) == (2 - np.array(self._path_connections)).sum()
        ):
            self._labels = labels

    def get_qpoints(self) -> list[NDArray[np.double]]:
        """Return q-points."""
        return [path[0] for path in self._paths]

    def get_distances(self) -> list[NDArray[np.double]]:
        """Return distances."""
        return [path[6] for path in self._paths]

    def get_gruneisen(self) -> list[NDArray[np.double]]:  # type: ignore[override]
        """Return mode Gruneisen parameters."""
        return [path[2] for path in self._paths]

    def get_eigenvalues(self) -> list[NDArray[np.double]]:  # type: ignore[override]
        """Return eigenvalues."""
        return [path[3] for path in self._paths]

    def get_eigenvectors(self) -> list[NDArray[np.cdouble]]:  # type: ignore[override]
        """Return eigenvectors."""
        return [path[4] for path in self._paths]

    def get_frequencies(self) -> list[NDArray[np.double]]:
        """Return frequencies."""
        return [path[5] for path in self._paths]

    def write_yaml(
        self,
        comment: Any = None,
        filename: str | os.PathLike | None = None,
        compression: Literal["gzip", "lzma"] | None = None,
    ) -> None:
        """Write results to file in yaml."""
        _filename: str | os.PathLike = ""
        if filename is not None:
            _filename = filename

        if compression is None:
            if filename is None:
                _filename = "gruneisen.yaml"
            with open(_filename, "w") as w:
                self._write_yaml(w, comment)
        elif compression == "gzip":
            if filename is None:
                _filename = "gruneisen.yaml.gz"
            with gzip.open(_filename, "wt") as w:
                self._write_yaml(w, comment)
        elif compression == "lzma":
            if filename is None:
                _filename = "gruneisen.yaml.xz"
            with lzma.open(_filename, "wt") as w:
                self._write_yaml(w, comment)

    def _write_yaml(self, w: IO[str], comment: Any) -> None:
        natom = len(self._cell)
        rec_lattice = np.linalg.inv(self._cell.cell)  # column vecs
        nq_paths = []
        for path in self._paths:
            nq_paths.append(len(path[0]))
        text = []
        if comment is not None:
            text.append(yaml.dump(comment, default_flow_style=False).rstrip())
        text.append("nqpoint: %-7d" % np.sum(nq_paths))
        text.append("npath: %-7d" % len(self._paths))
        text.append("segment_nqpoint:")
        text += ["- %d" % nq for nq in nq_paths]
        if self._labels:
            text.append("labels:")
            if self._is_legacy_plot:
                for i in range(len(self._paths)):
                    text.append(
                        "- [ '%s', '%s' ]" % (self._labels[i], self._labels[i + 1])
                    )
            else:
                assert self._path_connections is not None
                i = 0
                for c in self._path_connections:
                    text.append(
                        "- [ '%s', '%s' ]" % (self._labels[i], self._labels[i + 1])
                    )
                    if c:
                        i += 1
                    else:
                        i += 2
        text.append("reciprocal_lattice:")
        for vec, axis in zip(rec_lattice.T, ("a*", "b*", "c*"), strict=True):
            text.append("- [ %12.8f, %12.8f, %12.8f ] # %2s" % (tuple(vec) + (axis,)))
        text.append("natom: %-7d" % (natom))
        text.append(str(self._cell))
        text.append("")
        text.append("path:")
        text.append("")

        for band_structure in self._paths:
            (
                qpoints,
                distances,
                gamma,
                eigenvalues,
                _,
                frequencies,
                distances_with_shift,
            ) = band_structure

            text.append("- nqpoint: %d" % len(qpoints))
            text.append("  phonon:")
            for q, d, gs, freqs in zip(
                qpoints, distances, gamma, frequencies, strict=True
            ):
                text.append("  - q-position: [ %10.7f, %10.7f, %10.7f ]" % tuple(q))
                text.append("    distance: %10.7f" % d)
                text.append("    band:")
                for i, (g, freq) in enumerate(zip(gs, freqs, strict=True)):
                    text.append("    - # %d" % (i + 1))
                    text.append("      gruneisen: %15.10f" % g)
                    text.append("      frequency: %15.10f" % freq)
                text.append("")

        self._write_lines(w, text)

    def _write_lines(self, w: IO[str], lines: list[str]) -> None:
        text = "\n".join(lines)
        w.write(text)

    def plot(
        self, axarr: Any, epsilon: float | None = None, color_scheme: str | None = None
    ) -> None:
        """Return pyplot of band structure calculation results."""
        for band_structure in self._paths:
            self._plot(axarr, band_structure, epsilon, color_scheme)

    def _plot(
        self,
        axarr: Any,
        band_structure: BandPath,
        epsilon: float | None,
        color_scheme: str | None,
    ) -> None:
        (
            qpoints,
            distances,
            gamma,
            eigenvalues,
            _,
            frequencies,
            distances_with_shift,
        ) = band_structure

        n = len(gamma.T) - 1
        ax1, ax2 = axarr

        for i, (curve, freqs) in enumerate(
            zip(gamma.T.copy(), frequencies.T, strict=True)
        ):
            if epsilon is not None:
                if np.linalg.norm(qpoints[0]) < epsilon:
                    cutoff_index = 0
                    for j, q in enumerate(qpoints):
                        if not np.linalg.norm(q) < epsilon:
                            cutoff_index = j
                            break
                    for j in range(cutoff_index):
                        if abs(freqs[j]) < abs(max(freqs)) / 10:
                            curve[j] = curve[cutoff_index]

                if np.linalg.norm(qpoints[-1]) < epsilon:
                    cutoff_index = len(qpoints) - 1
                    for j in reversed(range(len(qpoints))):
                        q = qpoints[j]
                        if not np.linalg.norm(q) < epsilon:
                            cutoff_index = j
                            break
                    for j in reversed(range(len(qpoints))):
                        if j == cutoff_index:
                            break
                        if abs(freqs[j]) < abs(max(freqs)) / 10:
                            curve[j] = curve[cutoff_index]

            self._plot_a_band(ax1, curve, distances_with_shift, i, n, color_scheme)
        ax1.set_xlim(0, distances_with_shift[-1])

        for i, freqs in enumerate(frequencies.T):
            self._plot_a_band(ax2, freqs, distances_with_shift, i, n, color_scheme)
        ax2.set_xlim(0, distances_with_shift[-1])

    def _plot_a_band(
        self,
        ax: Any,
        curve: NDArray[np.double],
        distances_with_shift: NDArray[np.double],
        i: int,
        n: int,
        color_scheme: str | None,
    ) -> None:
        color = None
        if color_scheme == "RB":
            color = (1.0 / n * i, 0.0, 1.0 / n * (n - i))
        elif color_scheme == "RG":
            color = (1.0 / n * i, 1.0 / n * (n - i), 0.0)
        elif color_scheme == "RGB":
            color = (
                max(2.0 / n * (i - n / 2.0), 0),
                min(2.0 / n * i, 2.0 / n * (n - i)),
                max(2.0 / n * (n / 2.0 - i), 0),
            )
        if color:
            ax.plot(distances_with_shift, curve, color=color)
        else:
            ax.plot(distances_with_shift, curve)
