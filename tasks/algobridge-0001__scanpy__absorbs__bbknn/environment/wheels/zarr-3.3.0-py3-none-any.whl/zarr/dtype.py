from zarr.core.dtype import (
    Bool,
    Complex64,
    Complex128,
    DateTime64,
    DateTime64JSON_V2,
    DateTime64JSON_V3,
    FixedLengthUTF32,
    FixedLengthUTF32JSON_V2,
    FixedLengthUTF32JSON_V3,
    Float16,
    Float32,
    Float64,
    Int8,
    Int16,
    Int32,
    Int64,
    NullTerminatedBytes,
    NullterminatedBytesJSON_V2,
    NullTerminatedBytesJSON_V3,
    RawBytes,
    RawBytesJSON_V2,
    RawBytesJSON_V3,
    Struct,
    StructJSON_V3,
    Structured,
    StructuredJSON_V2,
    StructuredJSON_V3,
    TimeDelta64,
    TimeDelta64JSON_V2,
    TimeDelta64JSON_V3,
    UInt8,
    UInt16,
    UInt32,
    UInt64,
    VariableLengthBytes,
    VariableLengthBytesJSON_V2,
    VariableLengthUTF8,
    VariableLengthUTF8JSON_V2,
    ZDType,
    data_type_registry,
    # Import for backwards compatibility, but not included in __all__
    # so it doesn't show up in the docs
    parse_data_type,  # noqa: F401
    parse_dtype,
)
from zarr.core.dtype.common import DTypeSpec_V2, check_dtype_spec_v2

__all__ = [
    "Bool",
    "Complex64",
    "Complex128",
    "DTypeSpec_V2",
    "DateTime64",
    "DateTime64JSON_V2",
    "DateTime64JSON_V3",
    "FixedLengthUTF32",
    "FixedLengthUTF32JSON_V2",
    "FixedLengthUTF32JSON_V3",
    "Float16",
    "Float32",
    "Float64",
    "Int8",
    "Int16",
    "Int32",
    "Int64",
    "NullTerminatedBytes",
    "NullTerminatedBytesJSON_V3",
    "NullterminatedBytesJSON_V2",
    "RawBytes",
    "RawBytesJSON_V2",
    "RawBytesJSON_V3",
    "Struct",
    "StructJSON_V3",
    "Structured",
    "StructuredJSON_V2",
    "StructuredJSON_V3",
    "TimeDelta64",
    "TimeDelta64JSON_V2",
    "TimeDelta64JSON_V3",
    "UInt8",
    "UInt16",
    "UInt32",
    "UInt64",
    "VariableLengthBytes",
    "VariableLengthBytesJSON_V2",
    "VariableLengthUTF8",
    "VariableLengthUTF8JSON_V2",
    "ZDType",
    "check_dtype_spec_v2",
    "data_type_registry",
    "parse_dtype",
]


def __getattr__(name: str) -> object:
    if name == "DataTypeValidationError":
        import warnings

        from zarr.errors import DataTypeValidationError, ZarrDeprecationWarning

        warnings.warn(
            "Importing DataTypeValidationError from zarr.dtype is deprecated. "
            "Use zarr.errors.DataTypeValidationError instead.",
            ZarrDeprecationWarning,
            stacklevel=2,
        )
        return DataTypeValidationError
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
